import request from '@/util/request'

export function getFrontMenus() {
  return request({
    url: '/public/frontMenus',
    method: 'get',
  })
}
export function getBackMenus() {
  return request({
    url: '/backMenus',
    method: 'get',
  })
}
export function getMenuList(url, params) {
  return request({
    url: url,
    method: 'get',
    params:params
  })
}
