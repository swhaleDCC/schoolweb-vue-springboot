import request from '@/util/request'

export function validPass(pass) {
    return request({
        url: 'user/validPass/' + pass,
        method: 'get'
    })
}

export function updatePass(pass) {
    return request({
        url: 'user/updatePass/' + pass,
        method: 'get'
    })
}

export function updateEmail(email) {
    return request({
        url: 'user/updateEmail/' + email,
        method: 'get'
    })
}
export function getUserList(url, params) {

    return request({
        url: url,
        method: 'get',
        params:params
    })
}

