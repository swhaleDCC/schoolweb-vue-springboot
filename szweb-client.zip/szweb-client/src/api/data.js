import request from '@/util/request'

export function upload(data,url,params={dir:'image'}) {
    return request({
        url: url,
        method: 'post',
        params,
        data,
        headers:{'Content-Type':'multipart/form-data'}
    })
}
export function getList(url, params,type) {
    if(type!=null){
        url = url + '/' +type
    }

    return request({
        url: '/public/' + url,
        method: 'get',
        params:params
    })
}
export function addHit(url,id) {
    url='/public/'+url+'/'+id
    return request({
        url: url,
        method: 'put'
    })
}
export function update(data,url) {
    return request({
        url: url,
        method: 'put',
        data
    })
}
export function add(data,url,type='') {
    url = url + '/' + type
    return request({
        url: url,
        method: 'post',
        data
    })
}
export function del(id,url) {
    return request({
        url: url+'/' + id,
        method: 'delete'
    })
}
