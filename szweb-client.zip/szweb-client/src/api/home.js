import request from '@/util/request'

export function getHome() {
    return request({
        url: '/public/home',
        method: 'get',
    })
}
