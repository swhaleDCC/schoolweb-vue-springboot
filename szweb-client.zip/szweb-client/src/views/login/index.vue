<template>
  <v-container fill-height>
    <v-layout align-center justify-center>
      <v-flex xs12 sm8 md4>
        <v-card>
          <v-toolbar flat card dense dark>
            <v-icon>map</v-icon>
            <v-toolbar-title>用户登录</v-toolbar-title>
          </v-toolbar>
          <v-card-text>
            <form>
              <v-text-field
                prepend-icon="person"
                v-model="username"
                v-validate="'required|max:20|min:3'"
                :counter="20"
                :error-messages="errors.collect('username')"
                data-vv-name="username"
                required
              ></v-text-field>

              <v-text-field
                prepend-icon="lock"
                v-model="password"
                v-validate="'required|max:20|min:5'"
                :error-messages="errors.collect('password')"
                type="password"
                :counter="20"
                data-vv-name="password"
                required
              ></v-text-field>

              <v-text-field
                prepend-icon="spellcheck"
                v-model="testcode"
                :counter="20"
                required
                data-vv-name="testcode"
                placeholder="验证码"
              >
              </v-text-field>

              <div id="rig"> 
                <v-flex @click="refreshCode"><s-identify :identifyCode="identifyCode"></s-identify></v-flex>   
              </div>
              <div id="cen">
                <v-btn @click="submit">提交</v-btn>
                <v-btn @click="clear">复位</v-btn>
              </div>
            </form>
          </v-card-text>
        </v-card>
      </v-flex>
    </v-layout>
  </v-container>
</template>

<script>
import { CalcuMD5 } from "@/util/md5";
export default {
  name: "Login",
  data: () => ({
    identifyCodes: "1234567890",
    identifyCode: "",
    inputcode: "",
    username: "",
    password: "",
    testcode:"",
    dictionary: {
      attributes: {
        username: "账号",
        password: "密码",
        testcode:"验证码"
      }
    }
  }),
  mounted() {
    this.identifyCode = "";
    this.makeCode(this.identifyCodes, 4);
    this.$validator.localize("zh_CN", this.dictionary);
  },
  methods: {
    // 生成一个随机数
    randomNum(min, max) {
      return Math.floor(Math.random() * (max - min) + min);
    },
    refreshCode() {
      console.log(this.testcode);
      this.identifyCode = "";
      this.makeCode(this.identifyCodes, 4);

    },
    makeCode(a, b) {
      for (let i = 0; i < b; i++) {
        this.identifyCode += this.identifyCodes[
          this.randomNum(0, this.identifyCodes.length)
        ];
      }
    },
    submit() {
      this.$validator.validateAll().then(result => {
        if (result) {
          if (this.testcode===this.identifyCode) {
            const user = {
              username: this.username,
              password: CalcuMD5(this.password),
              testcode: CalcuMD5(this.testcode)
            };
            this.$store
              .dispatch("Login", user)
              .then(() => {
                this.$store
                  .dispatch("GetInfo")
                  .then(res => {
                    this.$router.push({ path: "/admin" });
                  })
                  .catch(() => {
                    this.$toasted.show("登录失败!");
                  });
              })
              .catch(() => {
                this.$toasted.show("登录失败!");
              });
          } 
          else {
            this.$toasted.show("验证码错误!");
            this.refreshCode();
            this.testcode="";
            this.$validator.reset();
          }
        } else {
          this.$toasted.show("数据输入不正确!");
        }
      });
    },
    clear() {
      this.username = "";
      this.password = "";
      this.testcode="";
      this.$validator.reset();
    }
  }
};
</script>

<style lang="stylus" scoped>
#cen{
  text-align :center;
}
#rig{
  text-align :right;
}
#rig v-but{
  width :20px;
  height :20px;
}
</style>
