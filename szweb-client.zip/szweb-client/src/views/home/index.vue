<template>
    <div id="home">
        <HomeHeader :flat="flat" ></HomeHeader>
        <v-app id="inspire">
            <v-content fluid fill-height>
                <transition name="fade-transform" mode="out-in">
                    <router-view />
                </transition>
            </v-content>
            <HomeFooter></HomeFooter>
        </v-app>

    </div>
</template>

<script>
    import HomeHeader from './components/HomeHeader'
    import HomeFooter from './components/HomeFooter'
    import HomeMain from './components/HomeMain'

    export default {
        name: "Layout",
        components: {
            HomeHeader,
            HomeFooter,
            HomeMain
        },
        created() {
            window.getApp = this
        },

        data(){
            return{
                flat:true
            }
        },

        mounted() {

            window.addEventListener("scroll", this.handleScroll);
        },
        methods: {


            handleScroll() {
                let scrollTop =
                    window.pageYOffset ||
                    document.documentElement.scrollTop ||
                    document.body.scrollTop;
                if (scrollTop > 10) {
                    this.flat = false;
                }
                if (scrollTop === 0) {
                    this.flat = true;
                }
            }
        }
    }
</script>

<style lang="stylus" scoped>

</style>
