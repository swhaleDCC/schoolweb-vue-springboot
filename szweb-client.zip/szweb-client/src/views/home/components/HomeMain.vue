<template>
  <div id="main">
    <!-- 轮播图 -->
    <v-layout row justify-center>
      <v-flex text-xs-center xs12>
        <v-carousel height="auto">
          <a
            v-for="(item,i) in carousels.items"
            :key="i"
            href="#"
            @click="handleDetail(carousels.url,carousels.type,carousels.name,item)"
          >
            <v-carousel-item :key="i" :src="item.imgurl"></v-carousel-item>
          </a>
        </v-carousel>
      </v-flex>
    </v-layout>

    <!-- 第一栏 -->
    <v-container fluid justify-center align-center style="padding-top:30px;padding-bottom:30px">
      <img src="/img/yknew.jpg">
      <v-layout wrap justify-center align-center>
        <v-flex  class="mt-4" justify-center align-center>
          <!-- <v-card align-center justify-center> -->
          <v-layout row wrap>
            <!-- 第一列 -->
            <v-layout column wrap>
              <v-flex v-for="(item,parentIndex) in [mainContent[1]]" :key="parentIndex">
                <v-card height="300" width="300">
                  <a href="#" @click.stop="handleMore(item.url,item.type)">
                    <v-img class="white--text" height="200px" src="/img/new7.jpg">
                      <v-container fill-height fluid>
                        <v-layout fill-height>
                          <v-flex xs12 align-end flexbox>
                            <span class="headline">{{item.name}}</span>
                          </v-flex>
                        </v-layout>
                      </v-container>
                    </v-img>
                  </a>
                  <section>
                    <v-list>
                      <template v-for="(subItem,subIndex) in [item.items[0]]">
                        <v-list-tile
                          ripple
                          :key="`${parentIndex}_${subIndex}`"
                          @click="handleDetail(item.url,item.type,item.name,subItem)"
                        >
                          <v-list-tile-content>
                            <v-list-tile-title :title="subItem.title">{{subItem.title}}</v-list-tile-title>
                            <v-list-tile-action-text>
                              <span>{{subItem.updateTime|formatDate}}</span>
                            </v-list-tile-action-text>
                          </v-list-tile-content>
                        </v-list-tile>
                      </template>
                    </v-list>
                  </section>
                  <v-card-actions>
                    <v-spacer></v-spacer>
                    <a href="#" @click.stop="handleMore(item.url,item.type)">
                      <v-btn color="primary">
                        <v-icon>more</v-icon>
                      </v-btn>
                    </a>
                  </v-card-actions>
                </v-card>
              </v-flex>
              <v-flex v-for="(item,parentIndex) in [mainContent[2]]" :key="parentIndex">
                <v-card height="300" width="300">
                  <a href="#" @click.stop="handleMore(item.url,item.type)">
                    <v-img class="white--text" height="200px" src="/img/new1.jpg">
                      <v-container fill-height fluid>
                        <v-layout fill-height>
                          <v-flex xs12 align-end flexbox>
                            <span class="headline">{{item.name}}</span>
                          </v-flex>
                        </v-layout>
                      </v-container>
                    </v-img>
                  </a>
                  <section>
                    <v-list>
                      <template v-for="(subItem,subIndex) in [item.items[0]]">
                        <v-list-tile
                          ripple
                          :key="`${parentIndex}_${subIndex}`"
                          @click="handleDetail(item.url,item.type,item.name,subItem)"
                        >
                          <v-list-tile-content>
                            <v-list-tile-title :title="subItem.title">{{subItem.title}}</v-list-tile-title>
                            <v-list-tile-action-text>
                              <span>{{subItem.updateTime|formatDate}}</span>
                            </v-list-tile-action-text>
                          </v-list-tile-content>
                        </v-list-tile>
                      </template>
                    </v-list>
                  </section>
                  <v-card-actions right>
                    <v-spacer></v-spacer>
                    <a href="#" @click.stop="handleMore(item.url,item.type)">
                      <v-btn color="primary">
                        <v-icon>more</v-icon>
                      </v-btn>
                    </a>
                  </v-card-actions>
                </v-card>
              </v-flex>
            </v-layout>
            <!-- 第二列 -->
            <v-layout column wrap>
              <v-flex v-for="(item,parentIndex) in [mainContent[3]]" :key="parentIndex">
                <v-card height="300" width="300">
                  <a href="#" @click.stop="handleMore(item.url,item.type)">
                    <v-img class="white--text" height="200px" src="/img/new4.jpg">
                      <v-container fill-height fluid>
                        <v-layout fill-height>
                          <v-flex xs12 align-end flexbox>
                            <span class="headline">{{item.name}}</span>
                          </v-flex>
                        </v-layout>
                      </v-container>
                    </v-img>
                  </a>
                  <section>
                    <v-list>
                      <template v-for="(subItem,subIndex) in [item.items[0]]">
                        <v-list-tile
                          ripple
                          :key="`${parentIndex}_${subIndex}`"
                          @click="handleDetail(item.url,item.type,item.name,subItem)"
                        >
                          <v-list-tile-content>
                            <v-list-tile-title :title="subItem.title">{{subItem.title}}</v-list-tile-title>
                            <v-list-tile-action-text>
                              <span>{{subItem.updateTime|formatDate}}</span>
                            </v-list-tile-action-text>
                          </v-list-tile-content>
                        </v-list-tile>
                      </template>
                    </v-list>
                  </section>
                  <v-card-actions right>
                    <v-spacer></v-spacer>
                    <a href="#" @click.stop="handleMore(item.url,item.type)">
                      <v-btn color="primary">
                        <v-icon>more</v-icon>
                      </v-btn>
                    </a>
                  </v-card-actions>
                </v-card>
              </v-flex>
              <v-flex v-for="(item,parentIndex) in [mainContent[4]]" :key="parentIndex">
                <v-card height="300" width="300">
                  <a href="#" @click.stop="handleMore(item.url,item.type)">
                    <v-img class="white--text" height="200px" src="/img/new2.jpg">
                      <v-container fill-height fluid>
                        <v-layout fill-height>
                          <v-flex xs12 align-end flexbox>
                            <span class="headline">{{item.name}}</span>
                          </v-flex>
                        </v-layout>
                      </v-container>
                    </v-img>
                  </a>
                  <section>
                    <v-list>
                      <template v-for="(subItem,subIndex) in [item.items[0]]">
                        <v-list-tile
                          ripple
                          :key="`${parentIndex}_${subIndex}`"
                          @click="handleDetail(item.url,item.type,item.name,subItem)"
                        >
                          <v-list-tile-content>
                            <v-list-tile-title :title="subItem.title">{{subItem.title}}</v-list-tile-title>
                            <v-list-tile-action-text>
                              <span>{{subItem.updateTime|formatDate}}</span>
                            </v-list-tile-action-text>
                          </v-list-tile-content>
                        </v-list-tile>
                      </template>
                    </v-list>
                  </section>
                  <v-card-actions right>
                    <v-spacer></v-spacer>
                    <a href="#" @click.stop="handleMore(item.url,item.type)">
                      <v-btn color="primary">
                        <v-icon>more</v-icon>
                      </v-btn>
                    </a>
                  </v-card-actions>
                </v-card>
              </v-flex>
            </v-layout>
            <!-- 第3列 -->
            <v-layout column wrap>
              <v-flex v-for="(item,parentIndex) in [mainContent[5]]" :key="parentIndex">
                <v-card height="300" width="300">
                  <a href="#" @click.stop="handleMore(item.url,item.type)">
                    <v-img class="white--text" height="200px" src="/img/new5.jpg">
                      <v-container fill-height fluid>
                        <v-layout fill-height>
                          <v-flex xs12 align-end flexbox>
                            <span class="headline">{{item.name}}</span>
                          </v-flex>
                        </v-layout>
                      </v-container>
                    </v-img>
                  </a>
                  <section>
                    <v-list>
                      <template v-for="(subItem,subIndex) in [item.items[0]]">
                        <v-list-tile
                          ripple
                          :key="`${parentIndex}_${subIndex}`"
                          @click="handleDetail(item.url,item.type,item.name,subItem)"
                        >
                          <v-list-tile-content>
                            <v-list-tile-title :title="subItem.title">{{subItem.title}}</v-list-tile-title>
                            <v-list-tile-action-text>
                              <span>{{subItem.updateTime|formatDate}}</span>
                            </v-list-tile-action-text>
                          </v-list-tile-content>
                        </v-list-tile>
                      </template>
                    </v-list>
                  </section>
                  <v-card-actions right>
                    <v-spacer></v-spacer>
                    <a href="#" @click.stop="handleMore(item.url,item.type)">
                      <v-btn color="primary">
                        <v-icon>more</v-icon>
                      </v-btn>
                    </a>
                  </v-card-actions>
                </v-card>
              </v-flex>
              <v-flex v-for="(item,parentIndex) in [mainContent[6]]" :key="parentIndex">
                <v-card height="300" width="300">
                  <a href="#" @click.stop="handleMore(item.url,item.type)">
                    <v-img class="white--text" height="200px" src="/img/new6.jpg">
                      <v-container fill-height fluid>
                        <v-layout fill-height>
                          <v-flex xs12 align-end flexbox>
                            <span class="headline">{{item.name}}</span>
                          </v-flex>
                        </v-layout>
                      </v-container>
                    </v-img>
                  </a>
                  <section>
                    <v-list>
                      <template v-for="(subItem,subIndex) in [item.items[0]]">
                        <v-list-tile
                          ripple
                          :key="`${parentIndex}_${subIndex}`"
                          @click="handleDetail(item.url,item.type,item.name,subItem)"
                        >
                          <v-list-tile-content>
                            <v-list-tile-title :title="subItem.title">{{subItem.title}}</v-list-tile-title>
                            <v-list-tile-action-text>
                              <span>{{subItem.updateTime|formatDate}}</span>
                            </v-list-tile-action-text>
                          </v-list-tile-content>
                        </v-list-tile>
                      </template>
                    </v-list>
                  </section>
                  <v-card-actions right>
                    <v-spacer></v-spacer>
                    <a href="#" @click.stop="handleMore(item.url,item.type)">
                      <v-btn color="primary">
                        <v-icon>more</v-icon>
                      </v-btn>
                    </a>
                  </v-card-actions>
                </v-card>
              </v-flex>
            </v-layout>
            <!-- 第4列   通知通告-->
            <v-layout column wrap>
              <v-flex xs12 sm6 v-for="(item,parentIndex) in [mainContent[0]]" :key="parentIndex">
                <v-card flat height="650" width="400">
                  <!-- 通知通告标题 -->
                  <div class="tit2">
                    <v-icon color="primary">notifications_none</v-icon>
                    {{item.name}}
                    <a href="#" @click.stop="handleMore(item.url,item.type)">
                      <v-btn icon color="primary">
                        <v-icon>more</v-icon>
                      </v-btn>
                    </a>
                  </div>
                  <!-- <v-toolbar color="primary" dark>
                        <v-icon>notifications_active</v-icon>
                        <v-toolbar-title>{{item.name}}</v-toolbar-title>
                        <v-spacer></v-spacer>
                        <a href="#" @click.stop="handleMore(item.url,item.type)">
                            <v-btn icon>
                                <v-icon>more</v-icon>
                            </v-btn>
                        </a>
                  </v-toolbar>-->
                  <section>
                    <!-- <img height="200px" width="400" src="/img/new3.jpg"> -->
                    <v-list three-line>
                      <template v-for="(subItem,subIndex) in item.items">
                        <v-list-tile
                          ripple
                          avatar
                          :key="`${parentIndex}_${subIndex}`"
                          @click="handleDetail(item.url,item.type,item.name,subItem) "
                        >
                          <!-- <v-list-tile-content>
                                    <v-list-tile-title :title="subItem.title">{{ subItem.title }}</v-list-tile-title>
                                    <v-list-tile-sub-title><span>{{subItem.updateTime|formatDate}}</span></v-list-tile-sub-title>
                                    <v-list-tile-action-text>
                                        <span>{{subItem.updateTime|formatDate}}</span>
                                    </v-list-tile-action-text>
                                    <v-spacer></v-spacer>
                                    <v-list-tile-action-text>
                                        <span>已阅读{{subItem.hit}}</span>
                                    </v-list-tile-action-text>
                          </v-list-tile-content>-->
                          <div class="date">
                            <span class="notop">{{subItem.updateTime|formatDay}}日</span>
                            <span class="nobtm">{{subItem.updateTime|formatMonth}}月</span>
                          </div>
                          <div class="text">
                            <h3 style="font-style:'楷体' ">{{ subItem.title }}</h3>
                          </div>
                        </v-list-tile>
                        <v-divider v-if="subIndex!==9" :key="subIndex"></v-divider>
                      </template>
                    </v-list>
                  </section>
                </v-card>
              </v-flex>
            </v-layout>
          </v-layout>
          <!-- </v-card> -->
        </v-flex>
      </v-layout>
    </v-container>

    <!-- 视频 -->
    <div id="video" style="background:url(/img/bgvideo.jpg); width: 100%; height: 500px;background-size: cover">
      <v-layout row justify-center>
        <v-flex>
          <v-btn color="primary" dark @click.stop="dialog = true" fab icon>
            <v-icon right amber bottom>arrow_drop_down_circle</v-icon>
          </v-btn>
          <v-dialog v-model="dialog" max-width="850">
            <v-card>
              <v-layout row justify-center>
                <v-card style="height:520px;width:820px;">
                  <video controls preload="metadata" width="800px" height="500px">
                    <source src="http://119v.pku.edu.cn/20180502pku.mp4" type="video/mp4">
                  </video>
                </v-card>
              </v-layout>
            </v-card>
          </v-dialog>
        </v-flex>
      </v-layout>
    </div>

    <!-- 校友风采 -->
    <div style="background:url(/img/bg1.jpg); width: 100%; height: 100%;background-size: cover;padding-top:30px;padding-bottom:30px">
       <div class="graduate-back mt-4">
      <v-container fluid text-sm-center grid-list-md>
        <a
          class="headline title-line mb-3"
          href="#"
          @click="handleMore(graduates.url,graduates.type)"
        ><img src="/img/xyfc.jpg" alt="" height="130" width="800" ></a>
        <v-layout row justify-center grid-list-md>
          <v-card>
            <v-flex>
              <v-layout column>
                <v-flex>
                  <!--  -->
                  <v-layout row>
                    <viewer>
                      <v-flex>
                        <img
                          src="http://www.tju.edu.cn/images/19/05/16/1s1le63o9c/W020190422597255778780.jpg"
                          style="height:200px;width:220px;"
                        >
                      </v-flex>
                    </viewer>

                    <viewer>
                      <v-flex>
                        <img
                          src="http://www.tju.edu.cn/images/19/05/16/1s1le63o9c/W020190422597549088987.jpg"
                          style="height:200px;width:220px;"
                        >
                      </v-flex>
                    </viewer>
                  </v-layout>
                </v-flex>

                <v-flex>
                  <v-hover>
                    <v-card slot-scope="{ hover }" :class="`elevation-${hover ? 12 : 2}`">
                      <a
                        href="#"
                        @click="handleDetail(graduates.url,graduates.type,graduates.name,graduates.items[0])"
                      >
                        <v-img :src="graduates.items[0].imgurl" style="width:450px;height:425px;"></v-img>
                      </a>
                    </v-card>
                  </v-hover>
                </v-flex>
              </v-layout>
            </v-flex>
          </v-card>

          <v-card>
            <v-flex>
              <v-layout column>
                <v-flex>
                  <v-layout row>
                    <v-flex>
                      <viewer>
                        <img
                          src="http://www.tju.edu.cn/images/19/05/16/1s1le63o9c/W020190422598148411572.jpg"
                          style="height:200px;width:220px;"
                        >
                      </viewer>
                    </v-flex>
                    <viewer>
                      <v-flex>
                        <img
                          src="http://www.tju.edu.cn/images/19/05/16/1s1le63o9c/W020190422598423620334.jpg"
                          style="height:200px;width:220px;"
                        >
                      </v-flex>
                    </viewer>
                  </v-layout>
                </v-flex>

                <v-flex>
                  <v-flex>
                    <v-layout row>
                      <v-flex>
                        <viewer>
                          <img
                            src="http://www.tju.edu.cn/images/19/05/16/1s1le63o9c/W020190422598713579141.jpg"
                            style="height:200px;width:220px;"
                          >
                        </viewer>
                      </v-flex>

                      <v-flex>
                        <viewer>
                          <img
                            src="http://www.tju.edu.cn/images/19/05/16/1s1le63o9c/W020190422599044988384.jpg"
                            style="height:200px;width:220px;"
                          >
                        </viewer>
                      </v-flex>
                    </v-layout>
                  </v-flex>
                </v-flex>

                <v-flex>
                  <v-flex>
                    <v-layout row>
                      <v-flex>
                        <viewer>
                          <img
                            src="http://www.tju.edu.cn/images/19/05/16/1s1le63o9c/W020190422599305721449.jpg"
                            style="height:200px;width:220px;"
                          >
                        </viewer>
                      </v-flex>

                      <v-flex>
                        <viewer>
                          <img
                            src="http://www.tju.edu.cn/images/19/05/16/1s1le63o9c/W020190422599591317694.jpg"
                            style="height:200px;width:220px;"
                          >
                        </viewer>
                      </v-flex>
                    </v-layout>
                  </v-flex>
                </v-flex>
              </v-layout>
            </v-flex>
          </v-card>

          <v-card>
            <v-flex d-flex xs12 sm6 md4>
              <v-layout column>
                <v-flex d-flex xs12 sm6 md4>
                  <a
                    href="#"
                    @click="handleDetail(graduates.url,graduates.type,graduates.name,graduates.items[1])"
                  >
                    <v-img :src="graduates.items[1].imgurl" style="width:450px;height:420px;"></v-img>
                  </a>
                </v-flex>

                <v-flex d-flex xs12 sm6 md4>
                  <viewer>
                    <img
                      src="http://www.tju.edu.cn/images/19/05/16/1s1le63o9c/W020190422600058733989.jpg"
                      style="width:450px;height:210px;"
                    >
                  </viewer>
                </v-flex>
              </v-layout>
            </v-flex>
          </v-card>
        </v-layout>
      </v-container>
      </div>
    </div>

    <!-- 应科故事 -->
    <div id="news" style="background:url(/img/bg4.jpg); width: 100%; height: 100%;background-size: cover">
      <div id="new">
        <a href="#" @click.stop="handleMore(storys.url,storys.type)">
          <img src="/img/story.png" alt height="120" width="400px">
        </a>
          <v-timeline color="#FFD54F" dark>
            <v-timeline-item v-for="(story, i) in storys.items" :key="i" :color="amber" small>
              <template v-slot:opposite  color="#FFD54F">
                <span :class="`headline`" ><font color="#FFD54F" style="font-size:'35px'" >{{story.title}} </font></span>
              </template>
              <a
                    href="#"
                    @click="handleDetail(storys.url,storys.type,storys.name,story)"
                  >
              <v-card class="elevation-2">
                <v-card-text class="headline" ><font style="font-family:'华文行楷';font-size:'20px'">{{story.content.substring(0,40)+str}}</font></v-card-text>
              </v-card>
              </a>
            </v-timeline-item>
          </v-timeline>
      </div>
      <vue-particles
        color="#dedede"
        :particleOpacity="0.2"
        :particlesNumber="80"
        shapeType="circle"
        :particleSize="3"
        linesColor="#dedede"
        :linesWidth="1"
        :lineLinked="true"
        :lineOpacity="0.4"
        :linesDistance="100"
        :moveSpeed="3"
        :hoverEffect="true"
        hoverMode="grab"
        :clickEffect="true"
        clickMode="push"
      ></vue-particles>
    </div>

  </div>
</template>
<script>
import { dateFilter } from "@/util";
import { getHome } from "@/api/home";
import { addHit } from "@/api/data";
import ToList from "@/mixins/ToList.mixins";
export default {
  name: "HomeMain",
  created() {
    this.getData();
  },
  mixins: [ToList],
  data() {
    return {
      mainContent: [],
      carousels: {},
      graduates: {},
      storys: {},
      dialog: false,
      str:"....."
    };
  },

  filters: dateFilter,
  methods: {
    getData() {
      getHome().then(res => {
        this.mainContent = res[0].items;
        this.carousels = res[2];
        this.graduates = res[1];
        this.storys = res[3];
      });
    },

    toggle(subIndex) {
      const i = this.selected.indexOf(subIndex);
      if (i > -1) {
        this.selected.splice(i, 1);
      } else {
        this.selected.push(subIndex);
      }
    },

    handleDetail(url, type, name, item) {
      this.$store.dispatch("setUrl", { url, type }).then(() => {
        this.$store.dispatch("setContent", item).then(() => {
          let title = null;
          if (type === "teaching") {
            title = "教研工作";
          }
          this.$store
            .dispatch("setTitle", { name: name, title: title })
            .then(() => {
              addHit(url, item.id).then(() => {
                this.$router.push("/pagedetail");
              });
            });
        });
      });
    }
  }
};
</script>

<style lang="stylus" scoped>
#news {
  width: 100%;
  text-align: center;
  align-items: center;
  justify-content: center;
}

#new {
  width: 60%;
  margin-left: 20%;
}

.tit2 {
  color: rgb(28, 68, 145);
  font-size: 30px;
  border-bottom: 4px solid rgb(28, 68, 145);
}

.date {
  background: url('http://schoolzq9.php168.net/skin/label/date_bg2.png') cover; // schoolzq9.php168.net/skin/label/date_bg2.png) cover;
  width: 100px;
  height: 100px;
  float: left;
}

a {
  text-decoration: none;
}

#video {
  align-items: center;
  justify-content: center;
  height = '500px';
}

.v-card--reveal {
  align-items: center;
  justify-content: center;
}

.title-line {
  text-decoration: none;
  color: #0c7ed9;
  height: 38px;
  line-height: 38px;
  border-bottom: 3px solid #ff9900;
}

.graduate-back {
  width: 100%;
  background-image: url('/img/bg1.jpg');
}

.item1 {
  padding: 20px 20px 20px 40px;
}

.item2 {
  padding: 20px;
}

.item3 {
  padding: 20px 40px 20px 20px;
}

.v-flex {
  height: 500px;
  width: 500px;
}

.v-footer {
  position: relative;
  justify-content: center;
}

.v-content {
  background: #f5f7f9 !important;
}

.div-title {
  display: flex;
  justify-content: space-between;
  padding-bottom: 0px;
  color: #0c7ed9;
  border-bottom: 2px solid #0c7ed9;

  span {
    background: #0c7ed9 !important;

    a {
      padding: 5px;
      color: #fff;
      font-size: 16px;
      line-height: 32px;
      text-decoration: none;
    }
  }
}

.date {
  width: 60px;
  height: 60px;
  background: url('http://schoolzq9.php168.net/skin/label/date_bg2.png') no-repeat; // schoolzq9.php168.net/skin/label/date_bg2.png) no-repeat;
  float: left;
}

.date span {
  height: 30px;
  line-height: 30px;
  display: block;
  text-align: center;
}

.notop {
  color: #ffffff;
  font-size: 20px;
}

.nobtm {
  color: #333333;
  font-size: 18px;
}

.text {
  margin-left: 10px;
  text-align: left;
  width: 260px;
  height: 60px;
  float: left;
  font-size: 13px;
  font-weight: lighter;
  font-style: '楷体';
}
</style>
