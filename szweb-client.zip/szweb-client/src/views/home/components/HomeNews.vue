<template>
  <div
    id="news"
    style="background:url(/img/bg4.jpg); width: 100%; height: 400px; background-size: cover"
  >
  <div id="new">
    <img src="/img/story.png" alt height="100" width="350px">
    <v-timeline>
      <v-timeline-item v-for="(story, i) in storys" :key="i" :color="amber" small>
        <template v-slot:opposite>
          <span :class="`headline font-weight-bold ${year.color}--text`" v-text="story.title"></span>
        </template>
        <!-- <v-card class="elevation-2">
        <v-card-title class="headline" v-text="story.content" color="amber"></v-card-title>
      </v-card> -->
      <p class="text-xs-left mt-3 pa-2" v-text="story.content" color="amber"></p>

      </v-timeline-item>
    </v-timeline>
    </div>

  </div>
</template>

<script>
export default {
  name: "HomeNews",
  data: () => ({
    years: [
      {
        color: "amber ",
        year: "1940",
        photo:
          "北京理工大学前身是1940年成立于延安的自然科学院，历经了晋察冀边区工业专门学校、华北大学工学院等办学时期。",
        content: "自然科学院"
      },
      {
        color: "amber ",
        year: "1949",
        photo:
          "1949年定址北京并接收中法大学校本部和数理化三个系，1952年定名为北京工业学院",
        content: "北京工业学院"
      },
      {
        color: "amber ",
        year: "1988",
        photo:
          "1988年更名为北京理工大学",
        content: "北京理工大学"
      },
      {
        color: "amber ",
        year: "2020",
        photo:
          "截至2020年3月，学校占地188公顷，建筑面积161万平方米，图书馆馆藏276.55万册，固定资产总额64.47亿元；教职工总数3420人，其中专任教师2284人",
        content: "北京理工大学"
      }
    ]
  })
};
</script>

<style>
#news {
  width: 100%;
  text-align: center;
  align-items: center;
  justify-content: center;
  height: 800px;
}
#new {
  width: 60%;
  margin-left: 20%;
}
</style>
