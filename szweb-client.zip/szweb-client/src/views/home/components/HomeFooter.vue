<template>
  <div id="footer">
      <v-footer dark height="auto" class="grey darken-3"> 
        <v-card flat tile class="text-xs-center">
          <v-card-text text>

                <a href="http://cs.bit.edu.cn/index.htm" target="_blank" >
                    <v-btn icon title="北理计算机学院官网">
                        <v-icon>home</v-icon>
                    </v-btn>
                </a>
                <a href="http://www.bit.edu.cn/" target="_blank" >
                    <v-btn icon title="北理官网">
                        <v-icon>home_work</v-icon>
                    </v-btn>
                </a>
                <a href="http://lib.bit.edu.cn/" target="_blank" >
                    <v-btn icon title="北理图书馆">
                        <v-icon>local_library</v-icon>
                    </v-btn>
                </a>
                <a href="https://weibo.com/bit1940?refer_flag=1001030103_" target="_blank" >
                    <v-btn icon title="北理微博">
                        <v-icon>cloud_queue</v-icon>
                    </v-btn>
                </a>

          </v-card-text>

          <v-card-text
            class="white--text pt-0"  
          >什么是北京理工大学计算机学院的信仰和力量？怎样才能当学霸？如何感受大学文化？你的梦想是什么？一群年轻的北理工“逐梦人”会给你答案！</v-card-text>

          <v-divider></v-divider>

          <v-card-text xs12 class="white--text" dark>
            地址：北京海淀区中关村南大街5号 邮编：100081
            <br/>
            &copy;2020 —青春逐梦人
          </v-card-text>
        </v-card>
      </v-footer>
  </div>
</template>

<script>
  export default {
    name: "HomeFooter",
  }
</script>

<style lang="stylus" scoped>
    footer {
        width :100%;
        justify-content: center;
        align-items: center;
    }

    a:link,a:visited{
        text-decoration:none;  /*超链接无下划线*/
    }


</style>
