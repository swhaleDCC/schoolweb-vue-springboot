<template>

    <div id="header">

        <div class="zero" >
            <v-toolbar dark color="#606060" :height="40" fixed>
            <v-toolbar-title class="white--text"></v-toolbar-title>
            
            <router-link :to="{path:'/map'}">
                <v-btn icon title="学院地址">
                    <v-icon>location_on</v-icon>
                </v-btn>
            </router-link>

            <router-link :to="{name:'home'}">
                <v-btn icon title="刷新">
                    <v-icon>refresh</v-icon>
                </v-btn>
            </router-link>

            <v-btn icon @click="handleFullScreen()">
                <v-icon>fullscreen</v-icon>
            </v-btn>

            <v-spacer></v-spacer>

            <v-menu v-if="!mobile" open-on-hover offset-y origin="center center"  transition="scale-transition">
                <template v-slot:activator="{ on }" right>
                    <v-btn icon v-on="on"  class="admin-btn">
                        <v-icon color="#ffffff">person</v-icon>
                    </v-btn>
                </template>

                <v-list class="pa-0">
                    <v-list-tile ripple :to="{path:'/login'}">
                        <v-list-tile-action>
                            <v-icon color="#005eb6">meeting_room</v-icon>
                        </v-list-tile-action>
                        <v-list-tile-title>登录</v-list-tile-title>
                    </v-list-tile>
                    <v-divider ></v-divider>
                    <v-list-tile :to="{path:'/register'}" ripple>
                        <v-list-tile-action>
                            <v-icon color="#005eb6">person_add</v-icon>
                        </v-list-tile-action>
                        <v-list-tile-title>注册</v-list-tile-title>
                    </v-list-tile>
                </v-list>
            </v-menu>  
        </v-toolbar>
        </div>

        <div class="one" style="margin-top:40px">
            <router-link :to="{name:'home'}">
                <img src="/img/bit.jpg" alt="">
            </router-link>
        </div>

        <div class="two">
            <v-navigation-drawer
                    id="appDrawer"
                    right
                    app
                    v-model="drawer" :width=290
            >
                <v-list dense expand>
                    <template v-for="item in mainContent">
                        <v-list-group
                            v-if="item.items.length!==0"
                            :key="item.title" :prepend-icon="item.icon"
                            :append-icon=" item['icon-alt']"
                        >
                            <!--group with subitems-->
                            <v-list-tile slot="activator" ripple="ripple" >
                                <v-list-tile-content>
                                    <v-list-tile-title style="font-size: 16px;"
                                                    class="ml-0 font-weight-bold title-margin">
                                        {{ item.title }}
                                    </v-list-tile-title>
                                </v-list-tile-content>
                            </v-list-tile>
                            <!--sub group-->
                            <v-list-tile class="ml-4" v-for="(subItem, i) in item.items" :key="i" @click="handleMore(item.name,subItem.name)">
                                <v-list-tile-action>
                                    <v-icon :size=24 color="#666">
                                        {{subItem.icon}}
                                    </v-icon>
                                </v-list-tile-action>
                                <v-list-tile-content>
                                    <v-list-tile-title style="font-size: 16px">{{ subItem.title }}</v-list-tile-title>
                                </v-list-tile-content>
                            </v-list-tile>
                        </v-list-group>
                        <v-list-tile v-else :key="item.title" @click="handleMore(item.name)">
                            <v-list-tile-action>
                                <v-icon color="#005eb6" :size=24>
                                    {{item.icon}}
                                </v-icon>
                            </v-list-tile-action>
                            <v-list-tile-content>
                                <v-list-tile-title style="font-size: 16px" class="font-weight-bold">
                                    {{ item.title }}
                                </v-list-tile-title>
                            </v-list-tile-content>

                        </v-list-tile>
                    </template>
                </v-list>
            </v-navigation-drawer>

            <div :flat="flat">
                <v-spacer></v-spacer>
                <nav id="menu" v-if="!mobile" > 
                    <ul>  
                        <template v-for="menu in menus">
                            <li v-if="menu.items.length!==0" :key="menu.title">
                                <a href="#">
                                    <v-icon>{{menu.icon}}</v-icon>
                                    <strong>{{menu.title}}</strong>
                                </a>
                                <ul>
                                    <li v-for="submenu in menu.items" :key="submenu.title">
                                        <a href="#" v-ripple @click="handleMore(menu.name,submenu.name)">
                                            <v-icon>{{submenu.icon}}</v-icon>
                                            {{submenu.title}}
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li v-else :key="menu.title">
                                <a href="#" v-ripple @click="handleMore(menu.name)">
                                    <v-icon>{{menu.icon}}</v-icon>
                                    <strong>{{menu.title}}</strong>
                                </a>
                            </li>                                               
                        </template>                    
                    </ul>                   
                </nav>             
            </div>
        </div>
    </div>
</template>

<script>
    import ToList from "@/mixins/ToList.mixins"
    import Vuetify from 'vuetify'
    import {getFrontMenus} from '@/api/menu'
    import 'vuetify/dist/vuetify.min.css'
    import 'material-design-icons-iconfont'
    import Util from '@/util';
    import {mapGetters} from 'vuex'

    export default {
        name: "HomeHeader",
        props: {
            flat: {
                type: Boolean,
                default: true
            }
        },
        
        computed:{
            mobile(){
                return this.$vuetify.breakpoint.xs||this.$vuetify.breakpoint.sm||this.$vuetify.breakpoint.md
            }
        },
        mounted(){
            this.getMenus()
        },
        mixins:[ToList],
        methods:{
            getMenus() {
                getFrontMenus().then(res => {
                    this.menus=res
                })
            },
            handleDrawerToggle() {
                this.collapsed = (!this.collapsed);
                window.getApp.$emit('APP_DRAWER_TOGGLED');
            },
            handleFullScreen() {
                Util.toggleFullScreen();
            },
        },
        data(){
            return{
                menus:[],
                drawer:false,
                login:{name: 'login'}
            }
        }
    }
</script>

<style lang="stylus" scoped>
    a {
        text-decoration: none;
    }

    /*菜单开始*/
    .menu-con
        width 690px;

    .one 
        width 100%
        height 150px
        top 40px
        img
            width 100%
            height 100%


    .two 
        background-color #005187
        width 100%
        height 55px
        display inline-block
        align-items center
        text-align center

    #menu
        ul
            list-style none
            padding-left 30px
            margin-top 10px
            border-radius 2px
            width 100%

            li
                display inline-block
                position relative
                width 15%

                a
                    display block
                    text-decoration none
                    color #fff
                    text-align left
                    line-height 28px

                    i
                        height auto
                        float left
                        line-height 28px !important
                        font-size 20px !important
                        margin-right 5px;
                        color #fff !important
                        position relative
                        transition all 300ms linear

                strong
                    display: block
                    font-size: 16px
                    font-weight: normal
                    position relative
                    transition all 300ms linear

            :hover > a i
                color #ffffff !important
                opacity 1
                animation moveFromRight 300ms ease-in-out

            :hover a strong
                color #ffffff
                opacity 1
                animation moveFromLeft 300ms ease-in-out

            a.active
                position relative
                color #ffffff
                border 0
                border-top 4px solid #e67e22
                border-bottom 4px solid #e67e22
                margin-top -4px
                box-shadow 0 0 5px #DDD

            a.active:before
                content ""
                position absolute

            a.active:after
                content ""
                position absolute
                top 42%
                right 0
                border-right 5px solid #e67e22
                border-top 5px solid transparent
                border-bottom 5px solid transparent

        ul li ul
            position absolute
            height auto
            width auto
            padding 0
            margin 0
            background #FFF
            opacity 0
            visibility hidden
            transition all 300ms linear
            z-index 1000
            display block
            top 60px
            border-top 4px solid #ffffff

            li
                list-style none
                display block
                width auto

                a
                    color #777
                    text-align left
                    border 0
                    border-bottom 1px solid #EEE
                    font-size 15px !important
                    line-height 32px
                    height auto
                    width auto !important
                    padding: 0 10px 0 0;

                    i
                        font-size 18px !important
                        line-height 32px !important
                        padding-left 10px
                        color #666 !important
            li: hover > a

            li:hover > a i
                color #ffffff !important

        li:hover > ul
            box-shadow 0 1px 6px rgba(0, 0, 0, .2)
            display block
            opacity 1
            visibility visible
            top 28px

        ul li ul:before
            content ""
            position absolute
            top -8px
            left 30%
            border-bottom 5px solid #ffffff
            border-left 5px solid transparent
            border-right 5px solid transparent

        @-webkit-keyframes moveFromTop
            from
                opacity 0
                transform translateY(200%)
            to
                opacity 1
                transform translateY(0%)
        @-webkit-keyframes moveFromLeft
            from
                opacity 0
                transform translateX(200%)
            to
                opacity 1
                transform translateX(0%)
        @-webkit-keyframes moveFromRight
            from
                opacity 0
                transform translateX(-200%)
            to
                opacity 1
                transform translateX(0%)

    /*===================== 菜单结束 ======================*/
</style>
