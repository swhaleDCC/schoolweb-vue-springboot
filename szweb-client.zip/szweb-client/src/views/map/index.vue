<template>
  <v-container>
    <v-layout align-center justify-center>
      <!-- <v-flex xs12 sm8 md4>
      <v-card>-->
      <div class="gmap_canvas" style="height:500px">
        <iframe
          id="gmap_canvas"
          width="100%"
          height="100%"
          src="https://map.baidu.com/search/%E5%8C%97%E4%BA%AC%E7%90%86%E5%B7%A5%E5%A4%A7%E5%AD%A6(%E4%B8%AD%E5%85%B3%E6%9D%91%E6%A0%A1%E5%8C%BA)/@12948714.75377907,4833449.3100000005,17.17z?querytype=s&da_src=shareurl&wd=%E5%8C%97%E4%BA%AC%E7%90%86%E5%B7%A5%E5%A4%A7%E5%AD%A6(%E4%B8%AD%E5%85%B3%E6%9D%91%E6%A0%A1%E5%8C%BA)&c=131&src=0&pn=0&sug=0&l=19&b=(12948822.131555231,4832984.635;12949542.131555231,4833378.635)&from=webmap&biz_forward=%7B%22scaler%22:2,%22styles%22:%22pl%22%7D&device_ratio=2"
          frameborder="0"
          scrolling="no"
          marginheight="0"
          marginwidth="0"
        />
      </div>
    </v-layout>
  </v-container>
</template>

<style lang="stylus">
.mapouter {
  text-align: right;
  height: 100%;
  width: 100%;
  position: absolute;
}

.gmap_canvas {
  overflow: hidden;
  background: none !important;
  height: 100%;
  width: 100%;
}
</style>


