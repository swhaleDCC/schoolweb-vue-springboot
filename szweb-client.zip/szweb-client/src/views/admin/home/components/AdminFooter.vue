<template>
  <v-footer dark height="auto">
    <v-card class="flex" flat tile>
      <v-card-title class="teal">
        <strong class="subheading">Get connected with us on social networks!</strong>
        <v-spacer></v-spacer>
        <v-layout row>
          <v-flex>
              <img src="/img/wechat3.jpg" width="50px" height="30px" @click.stop="dialog = true">
            <v-dialog v-model="dialog" max-width="300px" >
              <v-card>
                 <img src="/img/wechat.png" width="300px" height="300px">
              </v-card>
            </v-dialog>
          </v-flex>
          <v-flex>
              <img src="/img/QQ3.jpg" width="50px" height="30px" @click.stop="dialog = true">
            <v-dialog v-model="dialog" max-width="300px">
              <v-card>
                 <img src="/img/QQ.png" width="300px" height="300px">
              </v-card>
            </v-dialog>
          </v-flex>
        </v-layout>
      </v-card-title>

      <v-card-actions class="grey darken-3 justify-center">&copy;2020 —青春逐梦人</v-card-actions>
    </v-card>
  </v-footer>
</template>

<script>
export default {
  name: "AdminFooter",
  data: () => ({
    icons: [
      "fab fa-facebook",
      "fab fa-twitter",
      "fab fa-google-plus",
      "fab fa-linkedin",
      "fab fa-instagram"
    ],
    dialog: false
  })
};
</script>

<style scoped>
</style>
