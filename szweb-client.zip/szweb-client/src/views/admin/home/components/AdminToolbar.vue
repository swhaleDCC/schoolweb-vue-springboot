<template>
    <v-toolbar
            class="teal"
            fixed
            dark
            app
    >
        <v-toolbar-title class="ml-0 pl-3">
            <v-toolbar-side-icon @click.stop="handleDrawerToggle"
                                 :class="['sider-trigger-a', collapsed ? 'collapsed' : '']"></v-toolbar-side-icon>

            <span class="hidden-sm-and-down">管理控制台</span>
        </v-toolbar-title>

        <v-spacer></v-spacer>
        <v-menu open-on-hover offset-y origin="center center" transition="scale-transition">
            <v-btn icon large flat slot="activator">
                <v-avatar size="30px">
                    <img :src="avatar||'/avatar/test.jpg'"/>
                </v-avatar>
            </v-btn>
            <v-list class="pa-0">
                <template v-for="(item,index) in items">
                    <v-list-tile @click="item.click" ripple="ripple" :key="index">
                        <v-list-tile-action v-if="item.icon">
                            <v-icon color="#005eb6">{{ item.icon }}</v-icon>
                        </v-list-tile-action>
                        <v-list-tile-content>
                            <v-list-tile-title>{{ item.title }}</v-list-tile-title>
                        </v-list-tile-content>
                    </v-list-tile>
                    <v-divider></v-divider>
                </template>
            </v-list>
        </v-menu>
        <v-btn icon href="mailto:ljy@hainu.edu.cn">
            <v-icon>mail</v-icon>
        </v-btn>

        <v-btn icon @click="handleFullScreen()">
            <v-icon>fullscreen</v-icon>
        </v-btn>

        <router-link :to="{name:'home'}">
            <v-btn icon title="返回主页">
                <v-icon>arrow_back_ios</v-icon>
            </v-btn>
        </router-link>


    </v-toolbar>
</template>
<script>

    import Util from '@/util';
    import {mapGetters} from 'vuex'

    export default {
        name: 'app-toolbar',
        data() {
            return {
                collapsed: false,
                items: [
                    {
                        icon: 'account_circle',
                        href: '#',
                        title: '个人空间',
                        click: () => {
                            this.$router.push({path: '/space'})
                        }
                    },
                    {
                        icon: 'fullscreen_exit',
                        href: '#',
                        title: '退出登录',
                        click: () => {
                            this.$store.dispatch('Logout').then(() => {
                                this.$router.replace({path: '/login'});
                            })
                        }
                    }],
            }
        },
        computed: {
            ...mapGetters([
                'avatar',
                'authorities'
            ]),
        },
        methods: {
            handleDrawerToggle() {
                this.collapsed = (!this.collapsed);
                window.getApp.$emit('APP_DRAWER_TOGGLED');
            },
            handleFullScreen() {
                Util.toggleFullScreen();
            },

        }
    };
</script>
<style lang="stylus" scoped>
    .v-toolbar
        box-shadow: 0px 2px 6px rgba(0, 0, 0, 0.4), 0px 2px 6px rgba(0, 0, 0, 0.4)

    .trans
        transition: transform .2s ease;

    .sider-trigger-a

        &i
            transition: transform .2s ease;
            vertical-align top;

        &.collapsed i
            transform: rotateZ(90deg);
            transition: transform .2s ease;

</style>
