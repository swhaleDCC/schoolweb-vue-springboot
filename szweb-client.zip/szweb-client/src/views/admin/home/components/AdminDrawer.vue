<template>
    <v-navigation-drawer
            id="appDrawer"
            :mini-variant="mini"
            fixed
            :dark="$vuetify.dark"
            app
            v-model="drawer" :width=290
            color="success"
    >
        <v-toolbar class="teal">
            <span ><font style="font-size:30px;color:rgb(255,255,255)">应用科技学院</font></span>
        </v-toolbar>
        <vue-perfect-scrollbar class="drawer-menu--scroll" :settings="scrollSettings">
            <v-list dense expand>
                <template v-for="item in menus">
                    <v-list-group
                            v-if="item.items.length!==0"
                            :key="item.title" :prepend-icon="item.icon"
                            :append-icon=" item['icon-alt']"
                            color="rgb(0,150,136)"
                    >
                        <!--group with subitems-->
                        <v-list-tile slot="activator" ripple="ripple" >
                            <v-list-tile-content>
                                <v-list-tile-title style="font-size: 16px;"
                                                   class="ml-0 font-weight-bold title-margin">
                                    {{ item.title }}
                                </v-list-tile-title>
                            </v-list-tile-content>
                        </v-list-tile>
                        <!--sub group-->
                        <v-list-tile class="ml-4" v-for="(subItem, i) in item.items" :key="i" @click="handleMenu(item.name,subItem.name)">
                            <v-list-tile-action>
                                <v-icon :size=24 color="rgb(0,150,136)">
                                    {{subItem.icon}}
                                </v-icon>
                            </v-list-tile-action>
                            <v-list-tile-content>
                                <v-list-tile-title style="font-size: 16px">{{ subItem.title }}</v-list-tile-title>
                            </v-list-tile-content>
                        </v-list-tile>
                    </v-list-group>
                    <v-list-tile v-else :key="item.title" @click="handleMenu(item.name)">
                        <v-list-tile-action>
                            <v-icon color="rgb(0,150,136)" :size=24>
                                {{item.icon}}
                            </v-icon>
                        </v-list-tile-action>
                        <v-list-tile-content>
                            <v-list-tile-title style="font-size: 16px" class="font-weight-bold">
                                {{ item.title }}
                            </v-list-tile-title>
                        </v-list-tile-content>

                    </v-list-tile>
                </template>
            </v-list>
        </vue-perfect-scrollbar>
    </v-navigation-drawer>
</template>
<script>
    import { getBackMenus } from '@/api/menu';
    import VuePerfectScrollbar from 'vue-perfect-scrollbar';

    export default {
        name: 'admin-drawer',
        components: {
            VuePerfectScrollbar,

        },
        props: {
            expanded: {
                type: Boolean,
                default: true
            },
        },
        data: () => ({
            mini: false,
            drawer: true,
            menus: [],
            scrollSettings: {
                maxScrollbarLength: 160
            }
        }),

        created() {
            this.getMenus()
            window.getApp.$on('APP_DRAWER_TOGGLED', () => {
                this.mini = (!this.mini);
            });
        },


        methods: {
            handleMenu(url,type='') {
                this.$store.dispatch('setUrl', {url,type}).then(()=>{
                    if(type!=null){
                       url='/'+url+'List/'+type
                    }else{
                        url='/'+url+'List'
                    }

                    this.$router.push({path: url})
                })
            },
            getMenus() {
                getBackMenus().then(res => {
                    this.menus=res
                })
            },

        }
    };
</script>


<style lang="stylus">


    #appDrawer
        overflow: hidden

        .drawer-menu--scroll
            height calc(100vh - 48px)
            overflow auto

        .admin-logo
            margin-left: -3px;
            filter: drop-shadow(2px 1px 2px rgba(0, 0, 0, 0.8));


        .title-margin
            margin-left 32px;

        .icon-shadow
            filter: drop-shadow(2px 1px 2px rgba(0, 0, 0, 0.8));

        .v-icon
            color rgb(0,150,136)

        .v-toolbar
            box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.4), 2px 2px 6px rgba(0, 0, 0, 0.4)

        .v-toolbar
            margin-left -10px
            width 300px
</style>
