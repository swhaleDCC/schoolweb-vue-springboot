<template>
    <div>
        <v-container fill-height>
            <v-layout align-center justify-center>
                <v-flex xs12>
                    <v-card min-height="450">
                        <v-toolbar flat card height="60" color="#eee">
                            <v-toolbar-title>
                                <v-breadcrumbs :items="breadcrumbs" large divider=">"></v-breadcrumbs>
                            </v-toolbar-title>
                            <v-spacer/>

                            <v-flex xs4>

                            </v-flex>
                            <v-flex xs2 class="ml-4">
                                <v-btn round @click.stop="addItem">
                                    <v-icon left>add</v-icon>
                                    添加
                                </v-btn>
                            </v-flex>
                        </v-toolbar>
                        <v-card-text>
                            <v-data-table
                                    :rows-per-page-text="rowsText"
                                    :rows-per-page-items="rows"
                                    :headers="headers"
                                    :items="items"
                                    :pagination.sync="pagination"
                                    :total-items="total"
                                    :loading="loading"
                            >
                                <template v-slot:pageText="props">
                                    {{ props.pageStart }} - {{ props.pageStop }} / {{ props.itemsLength }}
                                </template>
                                <template v-slot:items="props">
                                    <td>{{ props.item.name }}</td>
                                    <td>{{props.item.title}} </td>
                                    <td>{{ props.item.icon}}</td>
                                    <td>{{ props.item.updateTime|formatDate }}</td>
                                    <td>
                                        <v-icon
                                                small
                                                class="mr-2"
                                                @click.stop="editItem(props.item)"
                                        >
                                            edit
                                        </v-icon>

                                        <v-icon
                                                small
                                                @click.stop="deleteItem(props.item.id)"
                                        >
                                            delete
                                        </v-icon>
                                    </td>
                                </template>
                            </v-data-table>
                        </v-card-text>
                    </v-card>
                    <v-dialog fullscreen hide-overlay transition="dialog-bottom-transition"
                              v-model="dialog1"

                    >
                        <v-card>
                            <v-toolbar color="primary" dark>
                                <v-toolbar-title>{{windowTitle}}</v-toolbar-title>
                                <v-spacer></v-spacer>
                                <v-btn class="mr-4" icon @click="dialog1=false">
                                    <v-icon>close</v-icon>
                                </v-btn>
                                <v-btn class="mr-4" round color="info" @click="submit">提交</v-btn>
                            </v-toolbar>
                            <v-card-text class="pa-4">
                                <form>
                                    <v-text-field
                                                  v-model="name"
                                                  label="菜单名称"
                                                  v-validate="'required'"
                                                  :error-messages="errors.collect('name')"
                                                  data-vv-name="name"
                                                  required
                                    ></v-text-field>
                                    <v-text-field
                                            v-model="title"
                                            v-validate="'required'"
                                            :error-messages="errors.collect('title')"
                                            label="菜单文本"
                                            data-vv-name="title"
                                    ></v-text-field>
                                    <v-text-field
                                            v-model="icon"
                                            v-validate="'required'"
                                            :error-messages="errors.collect('icon')"
                                            label="菜单图标"
                                            data-vv-name="icon"
                                    ></v-text-field>
                                    <h3>菜单角色：</h3>
                                    <v-checkbox v-for="n in 3" :key="n" class="ml-5"
                                                v-model="select"
                                                :value="values[n-1]"
                                                :label="texts[n-1]"
                                    ></v-checkbox>

                                </form>

                            </v-card-text>
                        </v-card>
                    </v-dialog>
                    <v-dialog
                            v-model="dialog2"
                            max-width="290"

                    >
                        <v-card min-height="200">
                            <v-toolbar flat card dense color="#f5f5f5">
                                <v-toolbar-title>提示信息</v-toolbar-title>
                            </v-toolbar>

                            <v-card-text class="text-xs-center">
                                <p>您确定要删除吗？</p>
                                <p>
                                    <v-btn @click="dialog2=false">关闭</v-btn>
                                    <v-btn @click="confirmed">确定</v-btn>
                                </p>
                            </v-card-text>
                        </v-card>
                    </v-dialog>
                </v-flex>
            </v-layout>
        </v-container>
    </div>

</template>

<script>
    import {getMenuList} from "@/api/menu";
    import {dateFilter} from "../../../util";
    import {mapGetters} from 'vuex'
    import {update, del} from "@/api/data";

    export default {
        name: "index",
        filters: dateFilter,

        data: () => ({
            id:'',
            name: '',
            title: '',
            select: [],
            actionType: '',
            icon:'',
            texts: ['系统管理员', '普通用户','开放的'],
            values: ['ROLE_ADMIN', 'ROLE_USER', 'ROLE_PUBLIC'],
            dictionary: {
                attributes: {
                    name: '菜单名称',
                    title: '菜单文本',
                    icon:'菜单图标'
                }
            },
            data: {id: 0, username: '', email: '', enabled: false, select: []},
            actionType: '',
            dialog1: false,
            dialog2: false,
            rows: [10, 30, 60, 100],
            rowsText: '每页行数：',
            total: 0,
            loading: false,
            pagination: {},
            headers: [
                {
                    text: '菜单名称',
                    align: 'left',
                    sortable: false,

                },
                {
                    text: '菜单文本',
                    align: 'left',
                    sortable: false,

                },
                {
                    text: '菜单图标',
                    align: 'left',
                    sortable: false,

                },

                {
                    text: '更新时间',
                    align: 'left',
                    sortable: false,

                },
                {
                    text: '操作',
                    align: 'left',
                    sortable: false,

                },

            ],

            breadcrumbs: [],
            items: []
        }),

        watch: {
            pagination: {
                handler() {
                    this.handleDataList()
                },
                deep: true
            }
        },
        mounted() {
            this.$validator.localize('zh_CN', this.dictionary);
        },
        computed: {
            windowTitle(){
                return this.actionType==='edit'?'编辑信息':'添加信息'
            },

            // 使用对象展开运算符将 getter 混入 computed 对象中
            ...mapGetters([
                'listUrl',
                'listType'
            ])
        },
        methods: {
            //添加数据事件处理
            addItem() {
                this.name = ''
                this.title = ''
                this.icon =''
                this.select = []
                this.dialog1 = true
                this.actionType = 'add'
            },
            //编辑数据事件处理
            editItem(item) {
                // alert(JSON.stringify(item))
                this.actionType = 'edit'
                this.id = item.id
                this.name = item.name
                this.title = item.title
                this.icon=item.icon
                this.select = []
                item.roles.forEach(role => {
                    this.select.push(role.name)
                })
                this.dialog1 = true
            },
            //删除数据的事件处理
            deleteItem(id) {
                this.dialog2 = true
                this.id = id
            },
            confirmed() {
                this.dialog2=false
                del(this.id,this.listUrl).then(data => {
                    if (data) {
                        this.$toasted.show('删除数据成功！')
                        this.handleDataList()
                    }
                }).catch(err => {
                    if (data) {
                        this.$toasted.show(err || '删除数据失败！')
                    }
                })
            },
            submit() {
                this.dialog1 = false
                this.$validator.validateAll().then((result) => {
                    if (result) {
                        let roles = []
                        this.select.forEach(item => {
                            switch (item) {
                                case 'ROLE_ADMIN':
                                    roles.push({id: 1, name: 'ROLE_ADMIN'})
                                    break
                                case 'ROLE_USER':
                                    roles.push({id: 2, name: 'ROLE_USER'})
                                    break
                                case 'ROLE_PUBLIC':
                                    roles.push({id: 3, name: 'ROLE_PUBLIC'})
                                    break
                            }

                        })

                        let menu = {
                            id: null,
                            name: this.name,
                            title: this.title,
                            icon: this.icon,
                            roles: roles
                        }
                        if (this.actionType === 'edit') {
                           menu.id = this.id
                        }

                        update(menu, this.listUrl).then(data => {
                            if (data) {
                                this.$toasted.show('数据编辑成功！')
                                this.handleDataList()
                            }
                        }).catch(err => {
                                this.$toasted.show(err || '数据编辑失败！')
                        })
                    }
                })
            },


            handleData(data) {
                let title = data.title
                this.breadcrumbs = []
                let item = {text: '首页', disabled: false, to: 'home'}
                this.breadcrumbs.push(item)
                if (title !== null && title !== '' && title !== undefined) {
                    item = {text: title, disabled: true, to: ''}
                    this.breadcrumbs.push(item)
                }
                item = {text: data.name, disabled: true, to: ''}
                this.breadcrumbs.push(item)
                this.$store.dispatch('setTitle', {name: data.name, title: title})
            },
            handleDataList() {
                this.loading = true
                const {page, rowsPerPage} = this.pagination
                getMenuList(this.listUrl, {pageIndex: page - 1, pageSize: rowsPerPage}).then(
                    (data) => {
                        if (data) {
                            this.items = data.page.content
                            this.total = data.page.totalElements
                            this.handleData(data)

                        } else {
                            this.$toasted.show('获取数据失败！')
                        }
                    }
                )
                this.loading = false
            }
        }
    }
</script>

<style lang="stylus" scoped>
    img
        height 32px
        border-radius 50%

</style>
