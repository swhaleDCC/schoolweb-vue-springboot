<template>
    <div>
        <v-dialog
                v-model="dialog"
                width="500"
        >
            <template v-slot:activator="{ on }">
                <p class="ml-3">
                    <v-btn v-on="on" round depressed>修改</v-btn>
                </p>
            </template>
            <v-card>
                <v-toolbar flat card dense color="#f5f5f5">
                    <v-toolbar-title>修改密码</v-toolbar-title>
                </v-toolbar>

                <v-card-text>
                    <form>
                        <v-text-field prepend-icon="lock" :type="show1 ? 'text' : 'password'"
                                      v-model="password" :append-icon="show1 ? 'visibility' : 'visibility_off'"
                                      v-validate="'required|max:20|min:5|validPass'"
                                      :error-messages="errors.collect('password')"
                                      label="原密码" :counter="20"
                                      data-vv-name="password"
                                      required @click:append="show1 = !show1"
                        ></v-text-field>
                        <v-text-field prepend-icon="lock" type="password" ref="newPassword"
                                      v-model="newPassword" :append-icon="show2 ? 'visibility' : 'visibility_off'"
                                      v-validate="'required|max:20|min:5'" :type="show2 ? 'text' : 'password'"
                                      :error-messages="errors.collect('newPassword')"
                                      label="新密码" :counter="20"
                                      data-vv-name="newPassword"
                                      required required @click:append="show2 = !show2"
                        ></v-text-field>
                        <v-text-field prepend-icon="lock" type="password" ref="confirmPassword"
                                      v-model="confirmPassword" :type="show3 ? 'text' : 'password'"
                                      v-validate="'required|max:20|min:5|confirmed:newPassword'"
                                      :error-messages="errors.collect('confirmPassword')"
                                      label="确认密码" :counter="20" :append-icon="show3 ? 'visibility' : 'visibility_off'"
                                      data-vv-name="confirmPassword"
                                      required @click:append="show3 = !show3"
                        ></v-text-field>

                        <v-btn @click="submit">提交</v-btn>
                        <v-btn @click="clear">复位</v-btn>
                        <v-btn @click="dialog=false">关闭</v-btn>
                    </form>
                </v-card-text>
            </v-card>
        </v-dialog>
    </div>
</template>

<script>

    import {CalcuMD5} from '@/util/md5'
    import {validPass, updatePass} from '@/api/user'

    export default {
        name: "UpdatePassword",
        data() {
            return {
                dialog: false,
                show1:false,
                show2:false,
                show3:false,
                password: '',
                newPassword: '',
                confirmPassword: '',
                dictionary: {
                    attributes: {
                        password: '旧密码',
                        newPassword: '新密码',
                        confirmPassword: '确认密码'
                    }
                }
            }
        },

        mounted() {
            this.$validator.localize('zh_CN', this.dictionary);
            const valid = value =>
                new Promise(resolve => {
                    validPass(CalcuMD5(value)).then(res => {
                        if (res.status === 200) {
                            return resolve({
                                valid: true
                            })
                        }
                        return resolve({
                            valid: false,
                            data: {
                                message: '密码输入不正确！'
                            }
                        })

                    })
                })

            this.$validator.extend("validPass", {
                validate: valid,
                getMessage: (field, params, data) => data.message
            });
        },
        methods: {
            submit() {
                this.$validator.validateAll().then((result)=> {
                    if (result) {
                        updatePass(CalcuMD5(this.confirmPassword)).then(res=>{
                            this.$toasted.show('密码修改成功,请重新登录！')
                            this.clear()
                            setTimeout(() => {
                                this.$store.dispatch('Logout').then(() => {
                                    this.$router.push({path:'/login'})
                                })
                            }, 1500)
                        })
                    }
                })
            },
            clear() {
                this.newPassword = ''
                this.password = ''
                this.confirmPassword = ''
                this.$validator.reset()
            }
        }
    }
</script>

<style scoped>

</style>
