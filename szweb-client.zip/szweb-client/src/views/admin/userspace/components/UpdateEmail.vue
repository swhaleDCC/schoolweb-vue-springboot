<template>
    <div>
        <v-dialog
                v-model="dialog"
                width="500"
        >
            <template v-slot:activator="{ on }">
                <p class="ml-3">
                    <v-btn v-on="on" round depressed>修改</v-btn>
                </p>
            </template>
            <v-card>
                <v-toolbar flat card dense color="#f5f5f5">
                    <v-toolbar-title>修改电子邮箱</v-toolbar-title>
                </v-toolbar>

                <v-card-text>
                    <form>
                        <v-text-field prepend-icon="email"
                                      v-model="email"
                                      v-validate="'required|email'"
                                      :error-messages="errors.collect('email')"
                                      label="输入新的电子邮箱"
                                      data-vv-name="email"
                                      required
                        ></v-text-field>

                        <v-btn @click="submit">提交</v-btn>
                        <v-btn @click="clear">复位</v-btn>
                        <v-btn @click="dialog=false">关闭</v-btn>
                    </form>

                </v-card-text>
            </v-card>
        </v-dialog>
    </div>
</template>

<script>
    import { updateEmail} from '@/api/user'
    export default {
        name: "UpdateEmail",
        data() {
            return {
                dialog:false,
                email: '',
                dictionary: {
                    attributes: {
                        email: '电子邮箱',
                    }
                }
            }
        },
        mounted() {
            this.$validator.localize('zh_CN', this.dictionary);
        },
        methods: {
            submit() {
                this.$validator.validateAll().then((result)=> {
                    if (result) {
                        updateEmail(this.email).then(res=>{
                            this.$toasted.show('电子邮箱修改成功！')
                            this.$store.dispatch('GetInfo').then(() => {})
                            this.dialog=false
                        }).catch(err=>{
                            this.$toasted.show(err||'电子邮箱修改失败！')
                        })
                    }
                })
            },
            clear () {
                this.email = ''
                this.$validator.reset()
            }
        }
    }
</script>

<style scoped>

</style>
