<template>
  <v-layout row>
    <v-flex xs12 sm6 offset-sm3>
      <v-card>
        <v-img src="/img/userspace.jpg" height="400px" >
          <v-layout column fill-height>
            <v-card-title>
              <!--离开按钮 -->
              <router-link :to="{path:'home'}" >
                <v-btn icon dark title="返回主页">
                    <v-icon>chevron_left</v-icon>
                </v-btn>
            </router-link>
              <v-spacer></v-spacer>
              <!-- 退出按钮 -->
              <router-link :to="{name:'login'}" >
                <v-btn icon dark title="退出登录" >
                  <v-icon>cancel</v-icon>
                </v-btn>
              </router-link>
            </v-card-title>

            <v-spacer></v-spacer>

            <v-card-title class="white--text pl-5 pt-5">
              <div class="display-1 pl-5 pt-5">{{name}}</div>
            </v-card-title>
          </v-layout>
        </v-img>
        <!-- 添加 -->
        <v-divider></v-divider>
        <v-list></v-list>
        <v-layout wrap>
          <!-- wrap自动换行 -->
          <!-- xs3和xs9已经满了，会自动换行 -->
          <v-flex xs3>
            <img :src="avatar||'/avatar/test.jpg'" height="170" class="card-img avatar">
          </v-flex>
          <v-flex xs9>
            <br/>
            <p class="ml-4">登录账户：{{username}}</p>
            <p class="ml-4">账户状态：正常</p>
            <!-- 没有click事件，单击会激活下面的插件，定义了一个id    trigger（插件里面）要加#-->
            <v-btn class="ml-4" round depressed id="pick-avatar">修改头像</v-btn>
          </v-flex>
          <!-- 插件：更换头像，前面加@的都是事件 -->
          <avatar-cropper
            @uploading="handleUploading"
            @uploaded="handleUploaded"
            @completed="handleCompleted"
            @error="handlerError"
            trigger="#pick-avatar"
            :upload-headers="headers"
            :upload-url="`${uploadFileUrl}?dir=avatar`"
          />
          <!-- :upload-url="`${uploadFileUrl}?dir=avatar`"必考格式。前面的内容取出来再跟后面的内容连起来  
          dir：参数的名字   avatar：参数的值——上传文件的类型    只有get请求才能这么传 -->
        </v-layout>
        <v-list two-line>
          <v-list-tile>
            <v-list-tile-action>
              <v-icon color="indigo">lock</v-icon>
            </v-list-tile-action>

            <v-list-tile-content>
              <v-list-tile-title>登录密码</v-list-tile-title>
            </v-list-tile-content>
            <update-password/>
           </v-list-tile>
           <v-divider inset></v-divider>
          <v-list-tile>
            <v-list-tile-action>
              <v-icon color="indigo">phone</v-icon>
            </v-list-tile-action>

            <v-list-tile-content>
              <v-list-tile-title>{{phone}}</v-list-tile-title>
            </v-list-tile-content>
          </v-list-tile>

          <v-divider inset></v-divider>

          <v-list-tile>
            <v-list-tile-action>
              <v-icon color="indigo">mail</v-icon>
            </v-list-tile-action>

            <v-list-tile-content>
              <v-list-tile-title>{{email}}</v-list-tile-title>
            </v-list-tile-content>
            <update-email/>
          </v-list-tile>

          <v-divider inset></v-divider>

          <v-list-tile>
            <v-list-tile-action>
              <v-icon color="indigo">location_on</v-icon>
            </v-list-tile-action>

            <v-list-tile-content>
              <v-list-tile-title>海南省儋州市那大镇两院</v-list-tile-title>
            </v-list-tile-content>
          </v-list-tile>
        </v-list>
      </v-card>
    </v-flex>
  </v-layout>
</template>

<script>
import AvatarCropper from "vue-avatar-cropper";
import { mapGetters } from "vuex";
import TitleBar from "@/components/TitleBar";
import { getToken } from "@/util/auth";
import UpdateEmail from "./components/UpdateEmail";
import UpdatePassword from "./components/UpdatePassword";
import { colors } from "vuetify/lib";

export default {
  components: { AvatarCropper, TitleBar, UpdateEmail, UpdatePassword },
  data() {
    return {
      headers: {
        Authorization: "Bearer " + getToken()
      }
      // 名值对   请求头
    };
  },

  computed: {
    ...mapGetters([
      "avatar",
      "username",
      "email",
      "createTime",
      "uploadFileUrl",
      "name",
      "phone",
      "last_password_reset_time"
    ])
    // 加this.可以直接用
  },
  methods: {
    handleUploading(form, xhr) {
      this.$toasted.info("上传中...");
    },
    handleUploaded(response) {
      if (response.error === 0) {
        this.$store.dispatch("GetInfo").then(() => {
          this.$toasted.success("头像修改成功");
        });
      }
    },
    handleCompleted(response, form, xhr) {},
    handlerError(message, type, xhr) {
      this.$toasted.show("头像修改失败");
    }
  }
};
</script>


<style lang="stylus">
a {
    text-decoration: none;
}
.router-link-active {
    text-decoration: none;
}
</style>
