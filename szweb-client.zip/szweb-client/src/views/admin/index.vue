<template>
  <div id="admin">
    <admin-drawer></admin-drawer>
    <admin-toolbar></admin-toolbar>
    <v-app>
      <v-content >
        <v-container fluid justify-center style=" min-height: calc(100vh - 114px)">
          <transition name="fade-transform" mode="out-in">
            <router-view />
          </transition>
        </v-container>
        <admin-footer></admin-footer>
      </v-content>
    </v-app>

  </div>

</template>
<script>
import AdminDrawer from './home/components/AdminDrawer'
import AdminToolbar from './home/components/AdminToolbar'
import AdminFooter from './home/components/AdminFooter'
export default {
  components: {
    AdminFooter,
    AdminDrawer,
    AdminToolbar,

  },
  created() {
    window.getApp = this
  }
}
</script>


<style lang="stylus" scoped>

</style>
