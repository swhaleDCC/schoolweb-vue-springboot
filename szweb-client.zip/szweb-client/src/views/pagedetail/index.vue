<template>
    <div id="pageList">
        <v-container fill-height>
            <v-layout align-center justify-center>
                <v-flex xs12>
                    <v-card min-height="450">
                        <v-toolbar flat card height="60"  color="rgb(0, 81, 135)">
                            <v-toolbar-title>
                                <v-breadcrumbs :items="breadcrumbs" large divider=">"></v-breadcrumbs>
                            </v-toolbar-title>
                        </v-toolbar>
                        <v-card-text class="text-xs-center pa-4">
                            <h3 class="headline">{{item.title}}</h3>
                            <section class="mt-2">
                                <span>阅读次数：{{item.hit+1}}</span>&nbsp;&nbsp;&nbsp;&nbsp;
                                <span>发布时间：{{item.updateTime | formatDate}}</span>
                            </section>
                            <v-divider class="mt-3"/>
                            <p class="text-xs-left mt-3 pa-2" v-html="item.content">

                            </p>

                        </v-card-text>
                    </v-card>
                </v-flex>
            </v-layout>
        </v-container>
    </div>
</template>

<script>

    import {dateFilter} from "../../util";

    export default {
        name: "index",
        filters: dateFilter,
        data: () => ({
            breadcrumbs: [],
            item: {content: '', title: '', updateTime: '', hit: 0}
        }),
        created() {
            this.getItem()
        },
        methods: {
            getItem() {
                this.item = this.$store.state.app.itemContent
                this.breadcrumbs = []
                let item = {text: '首页', disabled: false, to: 'home'}
                this.breadcrumbs.push(item)
                const title = this.$store.state.app.title
                const name = this.$store.state.app.name
                if (title !== null && title !== '' && title !== undefined) {
                    item = {text: title, disabled: true, to: ''}
                    this.breadcrumbs.push(item)
                }
                item = {text: name, disabled: false, to: 'pageList'}
                this.breadcrumbs.push(item)

                item = {text: '正文', disabled: true, to: ''}
                this.breadcrumbs.push(item)


            }
        }
    }
</script>

<style lang="stylus" scoped>
    .data-item
        cursor: pointer;

    .data-item:hover
        color orangered
        transform: scale(1.5)
        animation-duration: 0.6s
        animation-fill-mode: both
        animation-name: zoomIn
        direction: rtl

    @keyframes zoomIn
        from
            opacity: 0;
            transform: scale3d(.3, .3, .3);

        50%
            opacity: 1;


</style>
