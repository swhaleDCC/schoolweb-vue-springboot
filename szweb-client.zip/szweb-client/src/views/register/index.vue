

<template>

    <v-container fill-height>
<!--  -->


<!--  -->
        <v-layout align-center justify-center>
            <v-flex xs12 sm8 md4>
                <v-card >
                    
                    <v-toolbar height="40" dark primary-title>
                        <v-icon>map</v-icon>
                        用户注册
                    </v-toolbar>
                    <v-card-text>
                        <form>
                            <v-text-field
                                    v-model="username"
                                    prepend-icon="person"
                                    placeholder="账号" :counter="20"
                                    v-validate="'required|max:20|min:3'"
                                    :error-messages="errors.collect('username')"
                                    data-vv-name="username"
                                    required
                            ></v-text-field>
                            <v-text-field type="password" ref="password"
                                          prepend-icon="lock"
                                          v-model="password" :append-icon="show1 ? 'visibility' : 'visibility_off'"
                                          v-validate="'required|max:20|min:5'" :type="show1 ? 'text' : 'password'"
                                          :error-messages="errors.collect('password')"
                                          placeholder="密码" :counter="20"
                                          data-vv-name="password"
                                          required @click:append="show1 = !show1"
                            ></v-text-field>
                            <v-text-field type="password" ref="confirmPassword"
                                          prepend-icon="confirmation_number"
                                          v-model="confirmPassword" :type="show2 ? 'text' : 'password'"
                                          v-validate="'required|max:20|min:5|confirmed:password'"
                                          :error-messages="errors.collect('confirmPassword')"
                                          label="确认密码" :counter="20"
                                          :append-icon="show2 ? 'visibility' : 'visibility_off'"
                                          data-vv-name="confirmPassword"
                                          required @click:append="show2 = !show2"
                            ></v-text-field>
                            <v-text-field
                            prepend-icon="person_outline"
                                    v-model="name"
                                    label="姓名"
                            ></v-text-field>
                            <v-text-field
                            prepend-icon="phone"
                                    v-model="phone"
                                    label="电话"
                            ></v-text-field>
                            <v-text-field
                            prepend-icon="email"
                                    v-model="email"
                                    v-validate="'email'"
                                    :error-messages="errors.collect('email')"
                                    label="电子邮箱"
                                    data-vv-name="email"
                            ></v-text-field>

                            <h3>用户角色：</h3>
                            <v-radio-group v-model="role">
                                <v-radio v-for="n in 2" :key="n" class="ml-5 "

                                         :value="n"
                                         :label="texts[n-1]"
                                ></v-radio>
                            </v-radio-group>

                            <v-btn @click="submit">提交</v-btn>
                            <v-btn @click="clear">复位</v-btn>
                        </form>
                    </v-card-text>
                </v-card>
            </v-flex>
        </v-layout>
    </v-container>
</template>

<script>
    import {CalcuMD5} from '@/util/md5'
    import {register} from '@/api/auth'

    export default {
        name: "Register",

        data: () => ({
            show1: false,
            show2: false,
            username: '',
            password:'',
            confirmPassword:'',
            email: '',
            role: 2,
            name: '',
            phone: '',
            texts: ['系统管理员', '普通用户'],
            values: ['ROLE_ADMIN', 'ROLE_USER'],
            dictionary: {
                attributes: {
                    username: '账号',
                    email: '电子邮箱',
                    password: '新密码',
                    confirmPassword: '确认密码'
                }
            },
        }),

        mounted() {
            this.$validator.localize('zh_CN', this.dictionary)
        },

        methods: {
            submit() {
                this.$validator.validateAll().then((result) => {
                        if (result) {
                            let roles = []
                            roles.push({id: this.role, name: this.values[this.role - 1]})
                            let user = {
                                username: this.username,
                                email: this.email,
                                enabled: this.enabled,
                                name: this.name,
                                phone: this.phone,
                                authorities: roles,
                                password: CalcuMD5(this.confirmPassword)
                            }

                            register(user).then(data => {
                                if (data) {
                                    this.$toasted.show('注册成功，请联系管理员审核开通账户！')
                                    this.$router.push({path: '/home'})
                                }
                            }).catch(err => {
                                this.$toasted.show(err || '注册失败！')
                            })
                        }
                    }
                )
            },
            clear() {
                this.username = ''
                this.email = ''
                this.role=2
                this.name = ''
                this.phone = ''
                this.password = ''
                this.confirmPassword = ''
                this.$validator.reset()
                this.show1=false
                this.show2= false
            }
        }
    }
</script>

<style lang="stylus" scoped>

</style>

 