<template>
    <div id="pageList">
        <v-container fill-height>
            <v-layout align-center justify-center>
                <v-flex xs12>
                    <v-card min-height="450">
                        <v-toolbar flat card height="60" color="rgb(0, 81, 135)">
                            <v-toolbar-title color="rgb(255,255,255)" class="ml-0 font-weight-bold title-margin">
                                <v-breadcrumbs :items="breadcrumbs" large divider=">" ></v-breadcrumbs>
                            </v-toolbar-title>
                            <v-spacer/>

                            <v-flex xs4>
                                <v-text-field solo flat
                                              v-model="search"
                                              append-icon="search"
                                              label="输入标题中的关键字，按下回车开始搜索..."
                                              single-line
                                              hide-details @keyup.enter.native="handleSearch"
                                ></v-text-field>
                            </v-flex>
                        </v-toolbar>
                        <v-card-text>
                            <v-data-table
                                    :rows-per-page-text="rowsText"
                                    :rows-per-page-items="rows"
                                    :headers="headers"
                                    :items="items"
                                    :pagination.sync="pagination"
                                    :total-items="total"
                                    :loading="loading"
                            >  <template v-slot:pageText="props">
                                {{ props.pageStart }} - {{ props.pageStop }} / {{ props.itemsLength }}
                            </template>
                                    <template v-slot:items="props" >
                                        <td class="data-item" @click="toDetail(props.item)">{{ props.item.title }}</td>
                                        <td class="text-xs-right">{{ props.item.hit }}</td>
                                        <td class="text-xs-right">{{ props.item.updateTime|formatDate }}</td>
                                    </template>
                            </v-data-table>
                        </v-card-text>
                    </v-card>
                </v-flex>
            </v-layout>
        </v-container>
    </div>
</template>

<script>
    import {getList,addHit} from "@/api/data";
    import {dateFilter} from "@/util";
    import {mapGetters} from 'vuex'
    export default {
        name: "index",
        filters: dateFilter,
        data: () => ({
            rows: [5,10,30,60,90],
            rowsText: '每页行数：',
            total: 0,
            loading: false,
            pagination: {},
            headers: [
                {
                    text: '标题',
                    align: 'left',
                    sortable: false,
                    value: 'name'
                },
                {
                    text: '阅读次数',
                    align: 'right',
                    sortable: false,
                    value: 'hit'
                },
                {
                    text: '发布时间',
                    align: 'right',
                    sortable: false,
                    value: 'updateTime'
                },

            ],
            search: '',
            breadcrumbs: [],
            items: []
        }),
        watch: {
            '$route': function (to, from) {
                this.handleDataList()
            },
            pagination: {
                handler () {
                    this.handleDataList()
                },
                deep: true
            }
        },

        computed:{
            ...mapGetters([
                'listUrl',
                'listType'
            ])
        },
        methods: {
            handleSearch() {
                getList(this.listUrl, {title: this.search},this.listType).then(
                    (data) => {
                        if (data) {
                            this.items = data.page.content
                            this.total = data.page.totalElements
                            this.handleData(data)
                            this.search=''
                        } else {
                            this.$toasted.show('获取数据失败！')
                        }
                    }).catch(err => {
                    this.$toasted.show(err||'获取数据失败！')
                })
            },

            toDetail(item){
                this.$store.dispatch('setContent', item).then(()=>{
                    addHit(this.listUrl,item.id).then(()=>{
                        this.$router.push('/pagedetail')
                    })

                })

            },
            //搜索和列表共同的处理函数
            handleData(data) {
                let title = data.title
                this.breadcrumbs = []
                let item = {text: '首页', disabled: false, to: 'home'}
                this.breadcrumbs.push(item)
                if (title !== null && title !== '' && title !== undefined) {
                    item = {text: title, disabled: true, to: ''}
                    this.breadcrumbs.push(item)
                }
                item = {text: data.name, disabled: true, to: ''}
                this.breadcrumbs.push(item)
                this.$store.dispatch('setTitle', {name: data.name, title: title})
            },
            //处理列表
            handleDataList() {
                this.loading = true
                const {page, rowsPerPage} = this.pagination     
                getList(this.listUrl,  {pageIndex: page - 1, pageSize: rowsPerPage},this.listType,).then(
                    (data) => {
                        if (data) {
                            this.items = data.page.content
                            this.total = data.page.totalElements
                            this.handleData(data)
                        } else {
                            this.$toasted.show('获取数据失败！')
                        }
                    }
                )
                this.loading = false
            }
        }
    }
</script>

<style lang="stylus" scoped>
    .data-item
        cursor:pointer;
    .data-item:hover
        color orangered
        transform: scale(1.5)
        animation-duration: 0.6s
        animation-fill-mode: both
        animation-name: zoomIn
        direction: rtl
    @keyframes zoomIn
        from
            opacity: 0;
            transform: scale3d(.3, .3, .3);
        50%
            opacity: 1;

</style>
