<template>
    <router-view></router-view>
</template>

<script>
    export default {
    }
</script>
<style lang="stylus" >
    body
        font-size 16px
        font-family "Microsoft YaHei", "微软雅黑", "arial", "tahoma", "MicrosoftJhengHei"
        font-weight 400
        background #f5f7f9 !important
</style>
