import Vue from 'vue'
import Vuex from 'vuex'

import user from './module/user'
import app from './module/app'
import getters from './getters'
Vue.use(Vuex)

export default new Vuex.Store({    //store共享数据   user用户数据+app程序数据
  modules: {       
    user,
    app
  },
  getters       
})
