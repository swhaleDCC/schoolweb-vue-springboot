const baseUrl = process.env.VUE_APP_BASE_URL
export default {

    state: {           //定义变量  共享信息
        listUrl: '',
        listType: '',
        name:'',
        title:'',
        // editData:{},
        itemContent:{content:'',title:'',updateTime:'',hit:0},
        uploadFileUrl:baseUrl+'/uploadFile'
    },
    mutations: {      //定义方法   修改状态变量
        setListUrl(state, listUrl) {
            state.listUrl = listUrl
        },
        setListType(state, listType) {
            state.listType = listType
        },
        setItemName(state, name) {
            state.name = name
        },
        setItemTitle(state, title) {
            state.title = title
        },
        setItemContent(state, itemContent) {
            state.itemContent = itemContent
        },
        // setEditData(state,editData){
        //     state.editData=editData
        // }
    },
    actions: {             //声明方法    用来调用mutations      修改变量时只能调用actions
        setUrl(context, data) {
            context.commit('setListUrl', data.url)
            context.commit('setListType', data.type)
        },
        setTitle(context, data) {
            context.commit('setItemName', data.name)
            context.commit('setItemTitle', data.title)
        },
        setContent(context, data) {
            context.commit('setItemContent', data)

        },
    }
}
