import {login, getInfo} from '@/api/auth'
import {getToken, setToken,removeToken} from '@/util/auth'
import {parseTime} from '@/util'

const user = {
    state: {
        token: getToken(),
        username:'',
        name: '',
        phone:'',
        email: '',
        avatar: '',
        createTime: '',
        authorities:[]
    },
    mutations: {
        SET_TOKEN: (state, token) => {
            state.token = token
        },
        SET_USERNAME: (state, username) => {
            state.username = username
        },
        SET_NAME: (state, name) => {
            state.name = name
        },
        SET_PHONE: (state, phone) => {
            state.phone = phone
        },
        SET_AVATAR: (state, avatar) => {
            state.avatar =avatar
        },
        SET_AUTHORITIES: (state, authorities) => {
            state.authorities = authorities
        },
        SET_EMAIL: (state, email) => {
            state.email = email
        },

        SET_CREATE_TIME: (state, createTime) => {
            state.createTime = createTime
        },
    },

    actions: {
        // 登录
        Login({commit}, userInfo) {
            const username = userInfo.username
            const password = userInfo.password
            return new Promise((resolve, reject) => {
                login(username, password).then(res => {

                    commit('SET_TOKEN', res.token)
                    setToken(res.token)
                    resolve()
                }).catch(error => {
                    reject(error)
                })
            })
        },

        // 获取用户信息   会调用api函数  GetInfo用于更新图片信息
        GetInfo({commit}) {
            return new Promise((resolve, reject) => {
                getInfo().then(res => {

                    commit('SET_AUTHORITIES', res.authorities)
                    commit('SET_NAME', res.name)
                    commit('SET_USERNAME', res.username)
                    commit('SET_AVATAR', res.avatar)
                    commit('SET_EMAIL', res.email)
                    commit('SET_PHONE', res.phone)
                    commit('SET_CREATE_TIME',parseTime(res.createTime))

                    resolve(res)
                }).catch(error => {
                    reject(error)
                })
            })
        },

        // 登出
        Logout({commit}) {
            return new Promise((resolve, reject) => {
                commit('SET_TOKEN', '')
                removeToken();
                commit('SET_AUTHORITIES', [])
                resolve()
            })
        }
    }
}

export default user
