const getters = {

  token: state => state.user.token,
  avatar: state => state.user.avatar,
  phone:state => state.user.phone,
  name: state => state.user.name,
  username: state => state.user.username,
  createTime: state => state.user.createTime,
  email: state => state.user.email,
  authorities: state => state.user.authorities,
  listUrl: state => state.app.listUrl,
  listType: state => state.app.listType,
  // editData:state=>state.app.editData,
  itemName: state => state.app.name,
  itemTitle: state => state.app.title,
  uploadFileUrl:state => state.app.uploadFileUrl,
  itemContent: state => state.app.itemContent,

}
export default getters
