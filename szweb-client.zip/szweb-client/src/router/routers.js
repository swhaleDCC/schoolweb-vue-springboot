import AdminHome from '@/views/admin'
import Layout from '@/views/home'

export default [

  {
    path: '/Video',
    component: Layout,
    children: [
      {
        name: 'Video',
        path: '',
        component: () => import('@/views/map/index'),
      }
    ]
  },
  {
    path: '/map',
    component: Layout,
    children: [
      {
        name: 'map',
        path: '',
        component: () => import('@/views/map/index'),
      }
    ]
  },
  {
    path:'/space',
    component: () => import('@/views/admin/userspace/index')
  },
  {
    path: '/dynamic',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/notice',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/enrollment',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/story',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/party',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/cooperation',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/culture',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/carousel',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/graduate',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },

  {
    path: '/community/hot',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/community/research',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/education/undergraduate',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/education/graduates',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/education/continuing',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/scientific/project',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/scientific/institution',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/life/micromedia',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/life/youth',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/life/union',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/building/org',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/building/office',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },
  {
    path: '/download',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/download/index'),
      }
    ]
  },
  {
    path: '/admin',
    name: 'admin',
    component: AdminHome,

  },
  {
    path: '/',
    name: 'home',
    component: Layout,
    redirect:'/home',

    children: [{
      path: 'home',
      component: () => import('@/views/home/components/HomeMain')
    }]
  },
  {
    path: '/carouselList',
    component: AdminHome,
    children: [{
      name: 'carouselList',
      path: '',
      component: () => import('@/views/admin/carousel')
    }]
  },
  {
    path: '/graduateList',
    component: AdminHome,
    children: [{
      name: 'graduateList',
      path: '',
      component: () => import('@/views/admin/carousel')
    }]
  },
  {
    path: '/downloadList',
    component: AdminHome,
    children: [{
      name: 'downloadList',
      path: '',
      component: () => import('@/views/admin/download')
    }]
  },
  {
    path: '/dynamicList',
    component: AdminHome,
    children: [{
      name: 'dynamicList',
      path: '',
      component: () => import('@/views/admin/dynamic')
    }]
  },
  {
    path: '/noticeList',
    component: AdminHome,
    children: [{
      name: 'noticeList',
      path: '',
      component: () => import('@/views/admin/dynamic')
    }]
  },
  {
    path: '/enrollmentList',
    component: AdminHome,
    children: [{
      name: 'enrollmentList',
      path: '',
      component: () => import('@/views/admin/enrollment')
    }]
  },
  {
    path: '/storyList',
    component: AdminHome,
    children: [{
      name: 'storyList',
      path: '',
      component: () => import('@/views/admin/story')
    }]
  },
  {
    path: '/cultureList',
    component: AdminHome,
    children: [{
      name: 'cultureList',
      path: '',
      component: () => import('@/views/admin/dynamic')
    }]
  },
  {
    path: '/partyList',
    component: AdminHome,
    children: [{
      name: 'partyList',
      path: '',
      component: () => import('@/views/admin/enrollment')
    }]
  },
  {
    path: '/cooperationList',
    component: AdminHome,
    children: [{
      name: 'cooperationList',
      path: '',
      component: () => import('@/views/admin/cooperation')
    }]
  },
  {
    path: '/enroll',
    component: AdminHome,
    children: [{
      name: 'enroll',
      path: '',
      component: () => import('@/views/admin/dynamic')
    }]
  },
  {
    path: '/educationList/undergraduate',
    component: AdminHome,
    children: [{
      name: 'overviewList',
      path: '',
      component: () => import('@/views/admin/teachingResearch')
    }]
  },
  {
    path: '/educationList/graduates',
    component: AdminHome,
    children: [{
      name: 'overviewList',
      path: '',
      component: () => import('@/views/admin/teachingResearch')
    }]
  },
  {
    path: '/educationList/continuing',
    component: AdminHome,
    children: [{
      name: 'overviewList',
      path: '',
      component: () => import('@/views/admin/teachingResearch')
    }]
  },
  {
    path: '/communityList/research',
    component: AdminHome,
    children: [{
      name: 'teachingResearchList',
      path: '',
      component: () => import('@/views/admin/teachingResearch')
    }]
  },
  {
    path: '/communityList/hot',
    component: AdminHome,
    children: [{
      name: 'teachingResearchList',
      path: '',
      component: () => import('@/views/admin/teachingResearch')
    }]
  },
  {
    path: '/scientificList/institution',
    component: AdminHome,
    children: [{
      name: 'memberStudentList',
      path: '',
      component: () => import('@/views/admin/teachingResearch')
    }]
  },
  {
    path: '/scientificList/project',
    component: AdminHome,
    children: [{
      name: 'memberStudentList',
      path: '',
      component: () => import('@/views/admin/teachingResearch')
    }]
  },
  {
    path: '/lifeList/micromedia',
    component: AdminHome,
    children: [{
      name: 'employmentList',
      path: '',
      component: () => import('@/views/admin/teachingResearch')
    }]
  },
  {
    path: '/lifeList/union',
    component: AdminHome,
    children: [{
      name: 'employmentList',
      path: '',
      component: () => import('@/views/admin/teachingResearch')
    }]
  },
  {
    path: '/lifeList/youth',
    component: AdminHome,
    children: [{
      name: 'employmentList',
      path: '',
      component: () => import('@/views/admin/teachingResearch')
    }]
  },
  {
    path: '/buildingList/org',
    component: AdminHome,
    children: [{
      name: 'collaborationList',
      path: '',
      component: () => import('@/views/admin/teachingResearch')
    }]
  },
  {
    path: '/buildingList/office',
    component: AdminHome,
    children: [{
      name: 'collaborationList',
      path: '',
      component: () => import('@/views/admin/teachingResearch')
    }]
  },
  {
    path: '/userList',
    component: AdminHome,
    children: [{
      name: 'userList',
      path: '',
      component: () => import('@/views/admin/user')
    }]
  },

  {
    path: '/login',
    component: Layout,
    children: [
      {
        path: '',
        name: 'login',
        component: () => import('@/views/login/index'),

      }
    ]
  },
    {
        path: '/register',
        component: Layout,
        children: [
            {
                path: '',
                name: 'register',
                component: () => import('@/views/register/index'),
            }
        ]
    },
    {
        path: '/menulist',
        component: AdminHome,
        children: [{
            name: 'menuList',
            path: '',
            component: () => import('@/views/admin/menu')
        }]
    },

  {
    path: '/pageList',
    component: Layout,
    children: [
      {
        name: 'pageList',
        path: '',
        component: () => import('@/views/pagelist/index'),
      }
    ]
  },

  {
    path: '/pageDetail',
    component: Layout,
    children: [
      {
        path: '',
        name: 'PageDetail',
        component: () => import('@/views/pagedetail/index'),
      }
    ]
  },
  {
    path: '/401',
    name: 'error_401',
    meta: {
      hideInMenu: true
    },
    component: () => import('@/views/error-page/401.vue')
  },
  {
    path: '/500',
    name: 'error_500',
    meta: {
      hideInMenu: true
    },
    component: () => import('@/views/error-page/500.vue')
  },
  {
    path: '*',
    name: 'error_404',
    meta: {
      hideInMenu: true
    },
    component: () => import('@/views/error-page/404.vue')
  }
]
