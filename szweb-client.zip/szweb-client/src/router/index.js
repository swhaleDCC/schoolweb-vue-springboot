import Vue from 'vue'
import Router from 'vue-router'
import routes from './routers'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import store from '@/store'

Vue.use(Router)
const router = new Router({
    routes,
    mode: 'history'
})

router.beforeEach((to, from, next) => {
    NProgress.start()

    if (store.getters.token) {
        if (to.path === '/login'&&store.getters.authorities[0].name==='ROLE_ADMIN') {
            next({ path: '/admin' })
        } else {
            if (store.getters.authorities.length === 0) {
                store.dispatch('GetInfo').then(res => { // 拉取用户信息
                 next()
                }).catch((err) => {
                   console.log(JSON.stringify(err)||'拉取用户信息错误')
                    store.dispatch('Logout').then(() => {
                        next({ path: '/login' })
                    })
                })
            } else {
               next()
            }
        }
    } else {
       next()
    }
})

router.afterEach((to, from) => {
    // ...
    NProgress.done()
})

export default router
