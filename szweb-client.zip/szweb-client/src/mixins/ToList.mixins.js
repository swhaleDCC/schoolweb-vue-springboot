export default {
    methods: {
        handleMore(url, type=null) {
            this.$store.dispatch('setUrl', {url, type}).then(()=>{   //异步操作
                if(type!=null){
                    url='/'+url+'/'+type
                }else{
                    url='/'+url
                }
                this.$router.push({path: url})
            })

        },
    }

}
