<template>
        <editor  id='tinymce' v-model='data' @onKeyUp="handleChange" :init='init'></editor>
</template>

<script>
    import tinymce from 'tinymce/tinymce'
    import 'tinymce/themes/modern/theme'
    import Editor from '@tinymce/tinymce-vue'
    import "tinymce/plugins/advlist"
    import "tinymce/plugins/anchor"
    import "tinymce/plugins/autolink"
    import "tinymce/plugins/autosave"
    import "tinymce/plugins/code"
    import "tinymce/plugins/codesample"
    import "tinymce/plugins/colorpicker"
    import "tinymce/plugins/directionality"
    import "tinymce/plugins/fullscreen"
    import "tinymce/plugins/hr"
    import "tinymce/plugins/image"
    import "tinymce/plugins/imagetools"
    import "tinymce/plugins/insertdatetime"
    import "tinymce/plugins/link"
    import "tinymce/plugins/lists"
    import "tinymce/plugins/media"
    import "tinymce/plugins/nonbreaking"
    import "tinymce/plugins/noneditable"
    import "tinymce/plugins/pagebreak"
    import "tinymce/plugins/paste"
    import "tinymce/plugins/preview"
    import "tinymce/plugins/print"
    import "tinymce/plugins/save"
    import "tinymce/plugins/searchreplace"
    import "tinymce/plugins/spellchecker"
    import "tinymce/plugins/tabfocus"
    import "tinymce/plugins/table"
    import "tinymce/plugins/template"
    import "tinymce/plugins/textcolor"
    import "tinymce/plugins/textpattern"
    import "tinymce/plugins/visualblocks"
    import "tinymce/plugins/visualchars"
    import "tinymce/plugins/wordcount"
    import {upload} from '@/api/data'

    export default {
        name: "myeditor",
        data() {
            return {

                data:'',
                imgUrl:'',
                init: {
                       images_upload_handler:(blobInfo, success, failure)=> {
                        let formData = new FormData();
                        formData.append('file', blobInfo.blob(), blobInfo.filename());
                        upload(formData,this.uploadUrl).then((res)=>{
                             success(res.url)
                        }).catch(err=>{
                            failure(err)
                        })
                    },
                    language_url: '/tinymce/langs/zh_CN.js',
                    language: 'zh_CN',
                    skin_url: "/tinymce/skins/lightgray",
                    height: 300,
                    plugins:
                        "advlist anchor autolink autosave code codesample  colorpicker  directionality  fullscreen hr image imagetools insertdatetime link lists media nonbreaking noneditable pagebreak paste preview print save searchreplace spellchecker tabfocus table template textcolor textpattern visualblocks visualchars wordcount",
                    toolbar:
                        "bold italic underline strikethrough | fontsizeselect | forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist | outdent indent blockquote | undo redo | hr link unlink image code | removeformat preview fullscreen",
                    branding: false
                }
            };
        },
        props: {
            uploadUrl:'',
            value:''
        },
        mounted(){this.data=this.value},

        methods:{
            handleChange(){
            this.$emit('input',this.data);
            },
            uploadConfig(e) {
                let formData = new FormData();
                formData.append('file', e.target.files[0]);
                upload(formData,this.uploadFileUrl).then((response)=>{
                    this.imgUrl=response.url
                }).catch(err=>{
                    this.$toasted.show(err)
                })

            }
        },
        components: {Editor}
    };
</script>
