<template>
    <v-toolbar flat card :height="height" :color="color">
        <v-toolbar-title>
            <v-breadcrumbs :items="breadcrumbs" large divider=">"></v-breadcrumbs>
        </v-toolbar-title>
    </v-toolbar>
</template>

<script>
    export default {
        name: "TitleBar",
        data() {
            return {
                breadcrumbs: [
                    {text: '首页', disabled: false, to: 'home'}
                ]
            }
        },
        mounted() {
            if (this.items.length !== 0) {
                this.items.forEach(item => {
                    this.breadcrumbs.push(item)
                })
            }
        },
        props: {
            color: {
                type: String,
                default: '#EEEEEE'
            },
            height: {
                type: Number,
                default: 60
            },
            items:{
                type:Array,
                default: function () {
                    return []
                }
            }
        }
    }
</script>

<style scoped>

</style>
