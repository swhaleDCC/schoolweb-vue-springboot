<template>
    <div id="header">
        <v-toolbar :color="color" dark fixed app :height="100" :flat="flat" >
            <img src="/img/shuangzexx.png" alt="" height="60">
            <img class="ml-4" id="leaf" src="/img/leaf.gif"/>
            <nav id="menu">
                <ul>
                        <template v-for="menu in publicMenus"  >
                            <li  v-if="menu.items" :key="menu.title">
                                <a href="#">
                                    <v-icon>{{menu.icon}}</v-icon>
                                    <strong>{{menu.title}}</strong>
                                </a>
                                <ul >
                                    <li v-for="submenu in menu.items" :key="submenu.title">
                                        <a href="#" v-ripple>
                                            <v-icon>{{submenu.icon}}</v-icon>
                                            {{submenu.title}}
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li  v-else  :key="menu.title">
                                <a href="#" v-ripple>
                                    <v-icon>{{menu.icon}}</v-icon>
                                    <strong>{{menu.title}}</strong>
                                </a>
                            </li>
                        </template>
                </ul>
            </nav>
            <v-spacer></v-spacer>
            <v-btn icon large class="admin-btn">
                <v-icon>menu</v-icon>
            </v-btn>
        </v-toolbar>
    </div>
</template>

<script>
    import  menu from '@/api/menu'
    export default {
        name: "MainHeader",
        props: {
            color: {
                type: String,
                default: '#17406d'
            },
            flat: {
                type: Boolean,
                default: true
            }
        },
        data() {
           return  {
                menus: menu
            }
        },
        computed:{
            publicMenus(){
               return this.menus.filter(menu=>menu.public)
            }
        }
    }
</script>
<style lang="stylus" scoped>
    .v-toolbar
        img
            filter drop-shadow(2px 1px 2px rgba(0, 0, 0, 0.8))

    /*菜单开始*/
    .menu-con
        width 690px;
 #menu
    ul
        list-style none
        padding 0
        margin 0
        border-radius 2px
        width auto
        li
            display inline-block
            position relative
            width 110px
            a
                display block
                text-decoration none
                color #fff
                text-align left
                line-height 28px
                i
                    height auto
                    float left
                    line-height 28px !important
                    font-size 20px !important
                    margin-right 5px;
                    color #fff !important
                    position relative
                    transition all 300ms linear
            strong
                display: block
                font-size: 16px
                font-weight: normal
                position relative
                transition all 300ms linear
        :hover >a i
            color #e67e22 !important
            opacity 1
            animation moveFromRight 300ms ease-in-out
        :hover a strong
            color #e67e22
            opacity 1
            animation moveFromLeft 300ms ease-in-out
        a.active
            position relative
            color #e67e22
            border 0
            border-top 4px solid #e67e22
            border-bottom 4px solid #e67e22
            margin-top -4px
            box-shadow 0 0 5px #DDD
        a.active:before
            content ""
            position absolute
        a.active:after
            content ""
            position absolute
            top 42%
            right 0
            border-right 5px solid #e67e22
            border-top 5px solid transparent
            border-bottom 5px solid transparent
    ul li ul
        position absolute
        height auto
        width auto
        padding 0
        margin 0
        background #FFF
        opacity 0
        visibility hidden
        transition all 300ms linear
        z-index 1000
        display block
        top 60px
        border-top 4px solid #e67e22
        li
            list-style none
            display block
            width auto
            a
                color #777
                text-align left
                border 0
                border-bottom 1px solid #EEE
                font-size 15px !important
                line-height 32px
                height auto
                width auto !important
                padding: 0 10px 0 0;
                i
                    font-size 18px !important
                    line-height 32px !important
                    padding-left 10px
                    color #666 !important
        li:hover >a
        li:hover >a i
            color #e67e22  !important
    li:hover > ul
        box-shadow 0 1px 6px rgba(0, 0, 0, .2)
        display block
        opacity 1
        visibility visible
        top 28px
    ul li ul:before
        content ""
        position absolute
        top -8px
        left 30%
        border-bottom 5px solid #e67e22
        border-left 5px solid transparent
        border-right 5px solid transparent
    @-webkit-keyframes moveFromTop
        from
            opacity 0
            transform translateY(200%)
        to
            opacity 1
            transform translateY(0%)
    @-webkit-keyframes moveFromLeft
        from
            opacity 0
            transform translateX(200%)
        to
            opacity 1
            transform translateX(0%)
    @-webkit-keyframes moveFromRight
        from
            opacity 0
            transform translateX(-200%)
        to
            opacity 1
            transform translateX(0%)
    /*===================== 菜单结束 ======================*/
</style>
