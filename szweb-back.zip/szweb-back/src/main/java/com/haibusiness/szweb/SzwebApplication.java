package com.haibusiness.szweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class SzwebApplication {

    public static void main(String[] args) {

        SpringApplication.run(SzwebApplication.class, args);

    }

}

