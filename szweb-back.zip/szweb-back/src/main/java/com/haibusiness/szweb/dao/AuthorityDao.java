package com.haibusiness.szweb.dao;

import com.haibusiness.szweb.entity.Authority;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuthorityDao extends JpaRepository<Authority,Long> {
}
