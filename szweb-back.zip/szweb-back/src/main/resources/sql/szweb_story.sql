INSERT INTO szweb.story (id, hit, title, update_time, content, update_user) VALUES (1, 28, '1940', '2019-05-28 19:25:00', '北京理工大学前身是1940年成立于延安的自然科学院，历经了晋察冀边区工业专门学校、华北大学工学院等办学时期。', 1);
INSERT INTO szweb.story (id, hit, title, update_time, content, update_user) VALUES (2, 79, '1949', '2019-05-26 10:25:00', '1949年定址北京并接收中法大学校本部和数理化三个系，1952年定名为北京工业学院', 1);
INSERT INTO szweb.story (id, hit, title, update_time, content, update_user) VALUES (3, 75, '1988', '2019-05-24 20:25:00', '1988年更名为北京理工大学', 1);
