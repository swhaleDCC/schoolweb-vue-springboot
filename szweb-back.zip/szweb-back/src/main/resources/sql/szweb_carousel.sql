
INSERT INTO szweb.carousel (id, hit, title, update_time, content, imgurl, update_user) VALUES (1, 0, '图片新闻一', '2019-04-21 19:13:30', '<p>图片新闻一</p>', 'http://localhost:8000/upload/file/image/863bfe0b-01ad-456b-a94f-ba0cd1b1a89d.jpg', 1);
INSERT INTO szweb.carousel (id, hit, title, update_time, content, imgurl, update_user) VALUES (2, 2, '图片新闻二', '2019-04-25 16:44:16', '<p>图片新闻二</p>', 'http://localhost:8000/upload/file/image/2b9bb1c9-1115-4f9b-9572-26fc535b50ea.jpg', 1);
INSERT INTO szweb.carousel (id, hit, title, update_time, content, imgurl, update_user) VALUES (3, 2, '图片新闻三', '2019-04-25 15:46:12', '<p>图片新闻三</p>', 'http://localhost:8000/upload/file/image/93334002-52a8-4d75-9852-9509922af257.jpg', 1);
