INSERT INTO szweb.enrollment (id, hit, title, update_time, content, update_user) VALUES (1, 19, '硕士研究生','2019-04-17 10:11:00' ,"hhh ",1);
INSERT INTO szweb.enrollment (id, hit, title, update_time, content, update_user) VALUES (2, 19, '博士研究生','2019-04-17 10:11:00' ,"hhhzzz ",1);
